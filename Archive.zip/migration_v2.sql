-- ============================================================
-- TRACK FLOW — migration_v2.sql (idempotent upgrade path)
-- Run AFTER an existing v1 database.sql install.
-- Safe to run multiple times (no DROP TABLE).
--
-- Usage:
--   mysql your_database < migration_v2.sql
--   mysql your_database < migration_v2.sql   # second run = no-op
-- ============================================================

SET @db = DATABASE();

-- ── Helper: add column if missing ─────────────────────────────
DROP PROCEDURE IF EXISTS tf_add_column;
DELIMITER //
CREATE PROCEDURE tf_add_column(
    IN p_table VARCHAR(64),
    IN p_column VARCHAR(64),
    IN p_definition TEXT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = @db AND TABLE_NAME = p_table AND COLUMN_NAME = p_column
    ) THEN
        SET @sql = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_definition);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END//
DELIMITER ;

-- ── Helper: add index if missing ──────────────────────────────
DROP PROCEDURE IF EXISTS tf_add_index;
DELIMITER //
CREATE PROCEDURE tf_add_index(
    IN p_table VARCHAR(64),
    IN p_index VARCHAR(64),
    IN p_columns TEXT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = @db AND TABLE_NAME = p_table AND INDEX_NAME = p_index
    ) THEN
        SET @sql = CONCAT('ALTER TABLE `', p_table, '` ADD INDEX `', p_index, '` (', p_columns, ')');
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END//
DELIMITER ;

-- ============================================================
-- CLIENTS — extended fields
-- ============================================================
CALL tf_add_column('clients', 'skype', 'VARCHAR(100) NULL AFTER phone');
CALL tf_add_column('clients', 'telegram', 'VARCHAR(100) NULL AFTER skype');
CALL tf_add_column('clients', 'payment_terms', 'VARCHAR(100) NULL AFTER default_currency');
CALL tf_add_column('clients', 'billing_address', 'TEXT NULL AFTER payment_terms');

-- ============================================================
-- PROJECTS — v2 campaign fields
-- ============================================================
CALL tf_add_column('projects', 'short_code', 'VARCHAR(12) NULL AFTER project_code');
CALL tf_add_column('projects', 'currency', "VARCHAR(10) DEFAULT 'USD' AFTER client_cpi");
CALL tf_add_column('projects', 'daily_cap', 'INT DEFAULT 0 AFTER total_quota');
CALL tf_add_column('projects', 'preview_link', 'VARCHAR(500) NULL AFTER client_survey_link');
CALL tf_add_column('projects', 'visibility', "ENUM('private','public','invite_only') DEFAULT 'private' AFTER status");
CALL tf_add_column('projects', 'campaign_status', "ENUM('draft','pending_approval','testing','live','paused','completed','archived') DEFAULT 'live' AFTER visibility");
CALL tf_add_column('projects', 'vertical', "ENUM('Survey','E-commerce','Finance','Insurance','Home Improvement','Home Services','Real Estate','Education','Employment','Healthcare','Legal','Travel','Automotive','Gaming','Gambling','Dating','Sweepstakes','Mobile Apps','Software','Utilities','Subscription','Telecom','Food & Beverage','Beauty & Fashion','Electronics','Business Services','Lead Generation','Nonprofit','Entertainment','Other') DEFAULT 'Other' AFTER campaign_type");
CALL tf_add_column('projects', 'conversion_type', "ENUM('SOI','DOI','Lead','Sale','Install','Call','Trial','Subscription') DEFAULT 'SOI' AFTER vertical");
CALL tf_add_column('projects', 'target_device', "ENUM('All','Desktop','Mobile','Tablet') DEFAULT 'All' AFTER conversion_type");
CALL tf_add_index('projects', 'idx_campaign_status', 'campaign_status');

-- Backfill short_code where empty
UPDATE projects SET short_code = LOWER(SUBSTRING(MD5(CONCAT(id, project_code, RAND())), 1, 8))
WHERE short_code IS NULL OR short_code = '';

-- ============================================================
-- LEGACY VENDORS — extended fields
-- ============================================================
CALL tf_add_column('vendors', 'vendor_code', 'VARCHAR(20) NULL AFTER project_id');
CALL tf_add_column('vendors', 'company_name', 'VARCHAR(200) NULL AFTER vendor_name');
CALL tf_add_column('vendors', 'contact_person', 'VARCHAR(150) NULL AFTER company_name');
CALL tf_add_column('vendors', 'email', 'VARCHAR(150) NULL AFTER contact_person');
CALL tf_add_column('vendors', 'telegram', 'VARCHAR(100) NULL AFTER email');
CALL tf_add_column('vendors', 'skype', 'VARCHAR(100) NULL AFTER telegram');
CALL tf_add_column('vendors', 'traffic_type', "ENUM('Email','Facebook','Google','Native','Push','Incent','Search','Display','Influencer','API','Other') DEFAULT 'Other' AFTER contact_info");
CALL tf_add_column('vendors', 'vendor_status', "ENUM('pending','approved','suspended','blacklisted') DEFAULT 'approved' AFTER traffic_type");
CALL tf_add_column('vendors', 'daily_cap', 'INT DEFAULT 0 AFTER allowed_clicks_limit');
CALL tf_add_index('vendors', 'idx_vendor_code', 'vendor_code');

-- Backfill vendor_code
SET @vc_seq = 0;
UPDATE vendors SET vendor_code = CONCAT('V', LPAD((@vc_seq := @vc_seq + 1), 6, '0'))
WHERE vendor_code IS NULL OR vendor_code = '';

-- ============================================================
-- CLICKS — enrichment columns
-- ============================================================
CALL tf_add_column('clicks', 'country_code', 'CHAR(2) NULL AFTER country_detected');
CALL tf_add_column('clicks', 'browser', 'VARCHAR(50) NULL AFTER device_type');
CALL tf_add_column('clicks', 'os', 'VARCHAR(50) NULL AFTER browser');
CALL tf_add_column('clicks', 'browser_lang', 'VARCHAR(20) NULL AFTER os');
CALL tf_add_column('clicks', 'isp', 'VARCHAR(150) NULL AFTER browser_lang');
CALL tf_add_column('clicks', 'sub1', 'VARCHAR(200) NULL');
CALL tf_add_column('clicks', 'sub2', 'VARCHAR(200) NULL');
CALL tf_add_column('clicks', 'sub3', 'VARCHAR(200) NULL');
CALL tf_add_column('clicks', 'sub4', 'VARCHAR(200) NULL');
CALL tf_add_column('clicks', 'sub5', 'VARCHAR(200) NULL');
CALL tf_add_index('clicks', 'idx_country_code', 'country_code');
CALL tf_add_index('clicks', 'idx_browser', 'browser');
CALL tf_add_index('clicks', 'idx_os', 'os');

-- ============================================================
-- CONVERSIONS — enriched fields
-- ============================================================
CALL tf_add_column('conversions', 'sale_amount', 'DECIMAL(10,2) DEFAULT 0.00 AFTER client_revenue');
CALL tf_add_column('conversions', 'currency', "VARCHAR(10) DEFAULT 'USD' AFTER sale_amount");
CALL tf_add_column('conversions', 'transaction_id', 'VARCHAR(100) NULL AFTER currency');
CALL tf_add_column('conversions', 'click_time', 'DATETIME NULL AFTER transaction_id');
CALL tf_add_column('conversions', 'time_diff_seconds', 'INT NULL AFTER click_time');
CALL tf_add_column('conversions', 'approval_status', "ENUM('pending','approved','rejected') DEFAULT 'approved' AFTER is_manual");
CALL tf_add_index('conversions', 'idx_approval_status', 'approval_status');
CALL tf_add_index('conversions', 'idx_transaction_id', 'transaction_id');

-- ============================================================
-- SENT EMAILS — batch queue columns
-- ============================================================
CALL tf_add_column('sent_emails', 'retry_count', 'INT DEFAULT 0 AFTER error_message');
CALL tf_add_column('sent_emails', 'scheduled_for', 'DATETIME NULL AFTER retry_count');
CALL tf_add_column('sent_emails', 'batch_id', 'VARCHAR(50) NULL AFTER scheduled_for');
CALL tf_add_index('sent_emails', 'idx_status_sched', 'status, scheduled_for');
CALL tf_add_index('sent_emails', 'idx_batch', 'batch_id');

-- ============================================================
-- NEW TABLES (IF NOT EXISTS)
-- ============================================================

CREATE TABLE IF NOT EXISTS `global_vendors` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `vendor_code` VARCHAR(20) NOT NULL UNIQUE,
  `vendor_name` VARCHAR(200) NOT NULL,
  `company_name` VARCHAR(200) NULL,
  `contact_person` VARCHAR(150) NULL,
  `email` VARCHAR(150) NULL,
  `telegram` VARCHAR(100) NULL,
  `skype` VARCHAR(100) NULL,
  `phone` VARCHAR(50) NULL,
  `traffic_type` ENUM('Email','Facebook','Google','Native','Push','Incent','Search','Display','Influencer','API','Other') DEFAULT 'Other',
  `vendor_status` ENUM('pending','approved','suspended','blacklisted') DEFAULT 'approved',
  `default_payout` DECIMAL(10,2) DEFAULT 0.00,
  `currency` VARCHAR(10) DEFAULT 'USD',
  `daily_cap` INT DEFAULT 0,
  `notes` TEXT NULL,
  `created_by` INT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_status (`vendor_status`),
  INDEX idx_traffic (`traffic_type`),
  INDEX idx_email (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `project_vendor` (
  `project_id` INT NOT NULL,
  `vendor_id` INT NOT NULL,
  `payout` DECIMAL(10,2) DEFAULT 0.00,
  `currency` VARCHAR(10) DEFAULT 'USD',
  `status` ENUM('pending','approved','suspended') DEFAULT 'approved',
  `allowed_clicks_limit` INT DEFAULT 0,
  `daily_cap` INT DEFAULT 0,
  `assigned_by` INT NULL,
  `assigned_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `notes` TEXT NULL,
  PRIMARY KEY (`project_id`, `vendor_id`),
  INDEX idx_vendor (`vendor_id`),
  INDEX idx_status (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `short_links` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(12) NOT NULL UNIQUE,
  `project_id` INT NOT NULL,
  `vendor_id` INT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_project (`project_id`),
  INDEX idx_vendor (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `campaign_geo` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT NOT NULL,
  `country_code` CHAR(2) NOT NULL,
  `country_name` VARCHAR(100),
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_project_country (`project_id`, `country_code`),
  INDEX idx_country_code (`country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `campaign_notes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT NOT NULL,
  `body` TEXT NOT NULL,
  `created_by` INT,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_project (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `actor_id` INT NULL,
  `action` VARCHAR(100) NOT NULL,
  `entity_type` VARCHAR(50) NOT NULL,
  `entity_id` VARCHAR(100) NOT NULL,
  `before_json` JSON NULL,
  `after_json` JSON NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` VARCHAR(500) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_actor (`actor_id`),
  INDEX idx_entity (`entity_type`, `entity_id`),
  INDEX idx_created_at (`created_at`),
  INDEX idx_action (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `email_lists` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) NOT NULL,
  `source` VARCHAR(100) DEFAULT 'manual',
  `client_id` INT NULL,
  `project_id` INT NULL,
  `vendor_id` INT NULL,
  `is_deduped` TINYINT(1) DEFAULT 0,
  `record_count` INT DEFAULT 0,
  `description` TEXT NULL,
  `created_by` INT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_client (`client_id`),
  INDEX idx_project (`project_id`),
  INDEX idx_vendor (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `email_list_entries` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `list_id` INT NOT NULL,
  `email` VARCHAR(254) NOT NULL,
  `name` VARCHAR(200) NULL,
  `metadata_json` JSON NULL,
  `country` CHAR(2) NULL,
  `source` VARCHAR(100) NULL,
  `status` ENUM('active','unsubscribed','bounced','invalid') DEFAULT 'active',
  `is_unsubscribed` TINYINT(1) DEFAULT 0,
  `dedupe_hash` CHAR(40) NOT NULL,
  `added_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `last_emailed_at` DATETIME NULL,
  `total_emails_sent` INT DEFAULT 0,
  UNIQUE KEY uk_list_dedupe (`list_id`, `dedupe_hash`),
  INDEX idx_list (`list_id`),
  INDEX idx_email (`email`),
  INDEX idx_unsub (`is_unsubscribed`),
  INDEX idx_country (`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `email_campaigns` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT NOT NULL,
  `vendor_id` INT NOT NULL,
  `template_id` INT NULL,
  `name` VARCHAR(200) NOT NULL,
  `subject` VARCHAR(300) NOT NULL,
  `html_body` TEXT NOT NULL,
  `from_name` VARCHAR(150) NULL,
  `from_email` VARCHAR(150) NULL,
  `daily_limit` INT DEFAULT 1000,
  `total_limit` INT DEFAULT 0,
  `sent_count` INT DEFAULT 0,
  `delivered_count` INT DEFAULT 0,
  `opened_count` INT DEFAULT 0,
  `clicked_count` INT DEFAULT 0,
  `converted_count` INT DEFAULT 0,
  `bounced_count` INT DEFAULT 0,
  `unsubscribed_count` INT DEFAULT 0,
  `failed_count` INT DEFAULT 0,
  `status` ENUM('draft','scheduled','running','paused','completed','failed') DEFAULT 'draft',
  `is_multi_step` TINYINT(1) DEFAULT 0,
  `started_at` DATETIME NULL,
  `completed_at` DATETIME NULL,
  `created_by` INT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_project (`project_id`),
  INDEX idx_vendor (`vendor_id`),
  INDEX idx_status (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `email_campaign_sends` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `campaign_id` INT NOT NULL,
  `project_id` INT NOT NULL,
  `vendor_id` INT NOT NULL,
  `list_id` INT NOT NULL,
  `entry_id` BIGINT NOT NULL,
  `recipient_email` VARCHAR(254) NOT NULL,
  `recipient_name` VARCHAR(200) NULL,
  `country` CHAR(2) NULL,
  `status` ENUM('queued','sent','delivered','opened','clicked','converted','bounced','failed','skipped') DEFAULT 'queued',
  `resend_id` VARCHAR(100) NULL,
  `sent_at` DATETIME NULL,
  `opened_at` DATETIME NULL,
  `clicked_at` DATETIME NULL,
  `converted_at` DATETIME NULL,
  `error_message` TEXT NULL,
  `retry_count` INT DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_campaign_recipient (`campaign_id`, `recipient_email`),
  INDEX idx_campaign (`campaign_id`),
  INDEX idx_list (`list_id`),
  INDEX idx_status (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) NOT NULL,
  `subject` VARCHAR(300) NOT NULL,
  `html_body` TEXT NOT NULL,
  `is_default` TINYINT(1) DEFAULT 0,
  `created_by` INT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `client_documents` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `client_id` INT NOT NULL,
  `project_id` INT NULL,
  `document_type` VARCHAR(50) DEFAULT 'Other',
  `original_filename` VARCHAR(255) NOT NULL,
  `stored_filename` VARCHAR(255) NOT NULL,
  `file_size` BIGINT DEFAULT 0,
  `mime_type` VARCHAR(100) NULL,
  `uploaded_by` INT NULL,
  `notes` TEXT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_client (`client_id`),
  INDEX idx_project (`project_id`),
  INDEX idx_doc_type (`document_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `scheduled_reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `owner_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `report_type` VARCHAR(50) DEFAULT 'overview',
  `group_by` VARCHAR(50) DEFAULT 'project',
  `filters_json` JSON NULL,
  `frequency` ENUM('daily','weekly','monthly','custom_cron') DEFAULT 'daily',
  `custom_cron` VARCHAR(50) NULL,
  `recipients_csv` TEXT NULL,
  `last_run_at` DATETIME NULL,
  `next_run_at` DATETIME NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_owner (`owner_id`),
  INDEX idx_next_run (`next_run_at`),
  INDEX idx_active (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `vendor_portal_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `global_vendor_id` INT NOT NULL UNIQUE,
  `email` VARCHAR(150) NOT NULL,
  `password_hash` VARCHAR(255) NULL,
  `reset_token` VARCHAR(255) NULL,
  `reset_expires_at` DATETIME NULL,
  `magic_token` VARCHAR(255) NULL,
  `magic_expires_at` DATETIME NULL,
  `last_login_at` DATETIME NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Legacy client_documents installs may use type/filename/original_name/filesize/uploaded_at.
-- Dynamic renames are skipped here; fresh installs use database.sql canonical columns.

-- ============================================================
-- DATA BACKFILL: legacy vendors → global_vendors + project_vendor
-- ============================================================
INSERT IGNORE INTO global_vendors (
    vendor_code, vendor_name, company_name, contact_person, email, telegram, skype,
    traffic_type, vendor_status, default_payout, daily_cap, notes, created_at, updated_at
)
SELECT
    COALESCE(NULLIF(v.vendor_code, ''), CONCAT('V', LPAD(v.id, 6, '0'))),
    v.vendor_name,
    v.company_name,
    v.contact_person,
    v.email,
    v.telegram,
    v.skype,
    COALESCE(v.traffic_type, 'Other'),
    COALESCE(v.vendor_status, 'approved'),
    COALESCE(v.vendor_cpi, 0),
    COALESCE(v.daily_cap, 0),
    v.notes,
    v.created_at,
    NOW()
FROM vendors v
WHERE NOT EXISTS (
    SELECT 1 FROM global_vendors gv
    WHERE gv.vendor_code = COALESCE(NULLIF(v.vendor_code, ''), CONCAT('V', LPAD(v.id, 6, '0')))
);

INSERT IGNORE INTO project_vendor (project_id, vendor_id, payout, status, allowed_clicks_limit, daily_cap, assigned_at)
SELECT
    v.project_id,
    gv.id,
    COALESCE(v.vendor_cpi, 0),
    CASE WHEN v.status = 'active' OR v.vendor_status = 'approved' THEN 'approved'
         WHEN v.vendor_status IN ('suspended','blacklisted') THEN 'suspended'
         ELSE 'pending' END,
    COALESCE(v.allowed_clicks_limit, 0),
    COALESCE(v.daily_cap, 0),
    COALESCE(v.created_at, NOW())
FROM vendors v
JOIN global_vendors gv ON gv.vendor_code = COALESCE(NULLIF(v.vendor_code, ''), CONCAT('V', LPAD(v.id, 6, '0')));

-- ============================================================
-- SETTINGS (idempotent inserts)
-- ============================================================
INSERT INTO settings (setting_key, setting_value) VALUES
('global_postback_enabled', '0'),
('ip_enrichment_enabled', '1'),
('vendor_login_enabled', '0'),
('global_postback_url', ''),
('strict_target_device', '0'),
('email_bucket_tokens', '50'),
('email_bucket_last_ts', '0'),
('email_rate_per_minute', '50'),
('turnstile_enabled', '0'),
('turnstile_site_key', ''),
('turnstile_secret_key', '')
ON DUPLICATE KEY UPDATE setting_key = setting_key;

-- ============================================================
-- Cleanup helper procedures
-- ============================================================
DROP PROCEDURE IF EXISTS tf_add_column;
DROP PROCEDURE IF EXISTS tf_add_index;

-- Done. Re-run safe; no destructive changes.
