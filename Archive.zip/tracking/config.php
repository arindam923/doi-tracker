<?php
// ─── Secrets loader (Phase 9 hardening) ─────────────────────────
// env.php should sit outside the project webroot (sibling of the project folder).
$__env = __DIR__ . '/../../env.php';
if (is_file($__env)) { require_once $__env; }

if (!defined('DB_HOST')) define('DB_HOST', 'sql101.infinityfree.com');
if (!defined('DB_NAME')) define('DB_NAME', 'if0_42533255_bhbhbh');
if (!defined('DB_USER')) define('DB_USER', 'if0_42533255');
if (!defined('DB_PASS')) define('DB_PASS', 'vamaC9JgzFRljk');

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME .
  ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    die('Database connection failed: ' .
  htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
}