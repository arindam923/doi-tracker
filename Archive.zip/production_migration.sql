-- ============================================================
-- TRACK FLOW — Production Migration
-- Source: if0_42562417_23498237.sql snapshot
-- Adds columns + tables required by the latest codebase.
--
-- How to run in phpMyAdmin:
-- 1) Open your database → SQL tab
-- 2) Paste this whole file
-- 3) UNCHECK "Stop execution on error" if available
-- 4) Run
-- ============================================================

-- --------------------------------------------------------
-- CLIENTS: add missing contact fields
-- --------------------------------------------------------
ALTER TABLE `clients`
  ADD COLUMN `skype` VARCHAR(100) NULL AFTER `phone`,
  ADD COLUMN `telegram` VARCHAR(100) NULL AFTER `skype`,
  ADD COLUMN `payment_terms` VARCHAR(100) NULL AFTER `default_currency`,
  ADD COLUMN `billing_address` TEXT NULL AFTER `payment_terms`;

-- --------------------------------------------------------
-- PROJECTS: add new campaign + tracking fields
-- --------------------------------------------------------
ALTER TABLE `projects`
  ADD COLUMN `short_code` VARCHAR(12) UNIQUE NULL AFTER `project_name`,
  ADD COLUMN `preview_link` VARCHAR(500) NULL AFTER `client_survey_link`,
  ADD COLUMN `currency` VARCHAR(10) DEFAULT 'USD' AFTER `postback_token`,
  ADD COLUMN `daily_cap` INT DEFAULT 0 AFTER `total_quota`,
  ADD COLUMN `visibility` ENUM('private','public','invite_only') DEFAULT 'private' AFTER `status`,
  ADD COLUMN `campaign_status` ENUM('draft','pending_approval','testing','live','paused','completed','archived') DEFAULT 'live' AFTER `visibility`,
  ADD COLUMN `vertical` ENUM('Survey','E-commerce','Finance','Insurance','Home Improvement','Home Services','Real Estate','Education','Employment','Healthcare','Legal','Travel','Automotive','Gaming','Gambling','Dating','Sweepstakes','Mobile Apps','Software','Utilities','Subscription','Telecom','Food & Beverage','Beauty & Fashion','Electronics','Business Services','Lead Generation','Nonprofit','Entertainment','Other') DEFAULT 'Other' AFTER `campaign_status`,
  ADD COLUMN `conversion_type` ENUM('SOI','DOI','Lead','Sale','Install','Call','Trial','Subscription') DEFAULT 'SOI' AFTER `vertical`,
  ADD COLUMN `target_device` ENUM('All','Desktop','Mobile','Tablet') DEFAULT 'All' AFTER `conversion_type`,
  ADD KEY `idx_short_code` (`short_code`),
  ADD KEY `idx_campaign_status` (`campaign_status`);

-- Expand enums where possible
ALTER TABLE `projects`
  MODIFY COLUMN `campaign_type` ENUM('CPL','CPC','CPA','CPS','CPI','CPM','RevShare','Hybrid') DEFAULT 'CPL',
  MODIFY COLUMN `status` ENUM('live','hold','closed','archived') DEFAULT 'live';

-- --------------------------------------------------------
-- VENDORS: extend legacy per-project vendors
-- --------------------------------------------------------
ALTER TABLE `vendors`
  ADD COLUMN `vendor_code` VARCHAR(20) UNIQUE NULL AFTER `id`,
  ADD COLUMN `company_name` VARCHAR(200) NULL AFTER `project_id`,
  ADD COLUMN `contact_person` VARCHAR(150) NULL AFTER `company_name`,
  ADD COLUMN `email` VARCHAR(150) NULL AFTER `contact_person`,
  ADD COLUMN `telegram` VARCHAR(100) NULL AFTER `email`,
  ADD COLUMN `skype` VARCHAR(100) NULL AFTER `telegram`,
  ADD COLUMN `traffic_type` ENUM('Email','Facebook','Google','Native','Push','Incent','Search','Display','Influencer','API','Other') DEFAULT 'Other' AFTER `skype`,
  ADD COLUMN `vendor_status` ENUM('pending','approved','suspended','blacklisted') DEFAULT 'approved' AFTER `traffic_type`,
  ADD COLUMN `daily_cap` INT DEFAULT 0 AFTER `allowed_clicks_limit`,
  ADD COLUMN `vendor_cpi` DECIMAL(10,2) DEFAULT 0.00 AFTER `daily_cap`,
  ADD KEY `idx_vendor_code` (`vendor_code`),
  ADD KEY `idx_vendor_status` (`vendor_status`);

-- --------------------------------------------------------
-- CLICKS: add enrichment + sub params
-- --------------------------------------------------------
ALTER TABLE `clicks`
  ADD COLUMN `country_code` CHAR(2) NULL AFTER `country_detected`,
  ADD COLUMN `browser` VARCHAR(50) NULL AFTER `device_type`,
  ADD COLUMN `os` VARCHAR(50) NULL AFTER `browser`,
  ADD COLUMN `browser_lang` VARCHAR(20) NULL AFTER `os`,
  ADD COLUMN `isp` VARCHAR(150) NULL AFTER `browser_lang`,
  ADD COLUMN `sub1` VARCHAR(200) NULL AFTER `isp`,
  ADD COLUMN `sub2` VARCHAR(200) NULL AFTER `sub1`,
  ADD COLUMN `sub3` VARCHAR(200) NULL AFTER `sub2`,
  ADD COLUMN `sub4` VARCHAR(200) NULL AFTER `sub3`,
  ADD COLUMN `sub5` VARCHAR(200) NULL AFTER `sub4`,
  ADD KEY `idx_country_code` (`country_code`),
  ADD KEY `idx_browser` (`browser`),
  ADD KEY `idx_os` (`os`);

-- --------------------------------------------------------
-- CONVERSIONS: add finance + approval fields
-- --------------------------------------------------------
ALTER TABLE `conversions`
  ADD COLUMN `sale_amount` DECIMAL(10,2) DEFAULT 0.00 AFTER `client_revenue`,
  ADD COLUMN `currency` VARCHAR(10) DEFAULT 'USD' AFTER `sale_amount`,
  ADD COLUMN `transaction_id` VARCHAR(100) NULL AFTER `currency`,
  ADD COLUMN `click_time` DATETIME NULL AFTER `transaction_id`,
  ADD COLUMN `time_diff_seconds` INT NULL AFTER `click_time`,
  ADD COLUMN `approval_status` ENUM('pending','approved','rejected') DEFAULT 'approved' AFTER `is_manual`,
  ADD KEY `idx_approval_status` (`approval_status`),
  ADD KEY `idx_transaction_id` (`transaction_id`);

-- --------------------------------------------------------
-- USERS: add last login tracking
-- --------------------------------------------------------
ALTER TABLE `users`
  ADD COLUMN `last_login` DATETIME NULL AFTER `is_active`;

-- --------------------------------------------------------
-- SENT EMAILS: add retry + batch fields
-- --------------------------------------------------------
ALTER TABLE `sent_emails`
  ADD COLUMN `batch_id` VARCHAR(50) NULL AFTER `status`,
  ADD COLUMN `retry_count` INT DEFAULT 0 AFTER `batch_id`,
  ADD COLUMN `scheduled_for` DATETIME NULL AFTER `retry_count`,
  ADD KEY `idx_status_sched` (`status`, `scheduled_for`),
  ADD KEY `idx_batch` (`batch_id`);

-- --------------------------------------------------------
-- SETTINGS: add new feature flags
-- --------------------------------------------------------
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('global_postback_enabled', '0'),
('ip_enrichment_enabled', '1'),
('vendor_login_enabled', '0'),
('global_postback_url', ''),
('strict_target_device', '0'),
('email_bucket_tokens', '50'),
('email_bucket_last_ts', '0'),
('email_rate_per_minute', '50')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- --------------------------------------------------------
-- NEW TABLES
-- --------------------------------------------------------

-- GLOBAL VENDORS
CREATE TABLE IF NOT EXISTS `global_vendors` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `vendor_code` VARCHAR(20) NOT NULL UNIQUE,
  `vendor_name` VARCHAR(200) NOT NULL,
  `company_name` VARCHAR(200) NULL,
  `contact_person` VARCHAR(150) NULL,
  `email` VARCHAR(150) NULL,
  `telegram` VARCHAR(100) NULL,
  `skype` VARCHAR(100) NULL,
  `phone` VARCHAR(50) NULL,
  `traffic_type` ENUM('Email','Facebook','Google','Native','Push','Incent','Search','Display','Influencer','API','Other') DEFAULT 'Other',
  `vendor_status` ENUM('pending','approved','suspended','blacklisted') DEFAULT 'approved',
  `default_payout` DECIMAL(10,2) DEFAULT 0.00,
  `currency` VARCHAR(10) DEFAULT 'USD',
  `daily_cap` INT DEFAULT 0,
  `notes` TEXT NULL,
  `created_by` INT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_status (`vendor_status`),
  INDEX idx_traffic (`traffic_type`),
  INDEX idx_email (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- PROJECT ↔ VENDOR PIVOT
CREATE TABLE IF NOT EXISTS `project_vendor` (
  `project_id` INT NOT NULL,
  `vendor_id` INT NOT NULL,
  `payout` DECIMAL(10,2) DEFAULT 0.00,
  `currency` VARCHAR(10) DEFAULT 'USD',
  `status` ENUM('pending','approved','suspended') DEFAULT 'approved',
  `allowed_clicks_limit` INT DEFAULT 0,
  `daily_cap` INT DEFAULT 0,
  `assigned_by` INT NULL,
  `assigned_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `notes` TEXT NULL,
  PRIMARY KEY (`project_id`, `vendor_id`),
  INDEX idx_vendor (`vendor_id`),
  INDEX idx_status (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- SHORT LINKS
CREATE TABLE IF NOT EXISTS `short_links` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(12) NOT NULL UNIQUE,
  `project_id` INT NOT NULL,
  `vendor_id` INT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_project (`project_id`),
  INDEX idx_vendor (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- CAMPAIGN GEO
CREATE TABLE IF NOT EXISTS `campaign_geo` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT NOT NULL,
  `country_code` CHAR(2) NOT NULL,
  `country_name` VARCHAR(100),
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_project_country (`project_id`, `country_code`),
  INDEX idx_country_code (`country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- CAMPAIGN NOTES
CREATE TABLE IF NOT EXISTS `campaign_notes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT NOT NULL,
  `body` TEXT NOT NULL,
  `created_by` INT,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_project (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- AUDIT LOGS
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `actor_id` INT NULL,
  `action` VARCHAR(100) NOT NULL,
  `entity_type` VARCHAR(50) NOT NULL,
  `entity_id` VARCHAR(100) NOT NULL,
  `before_json` JSON NULL,
  `after_json` JSON NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` VARCHAR(500) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_actor (`actor_id`),
  INDEX idx_entity (`entity_type`, `entity_id`),
  INDEX idx_created_at (`created_at`),
  INDEX idx_action (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- EMAIL LISTS
CREATE TABLE IF NOT EXISTS `email_lists` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) NOT NULL,
  `source` VARCHAR(100) DEFAULT 'manual',
  `client_id` INT NULL,
  `project_id` INT NULL,
  `vendor_id` INT NULL,
  `is_deduped` TINYINT(1) DEFAULT 0,
  `record_count` INT DEFAULT 0,
  `description` TEXT NULL,
  `created_by` INT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_client (`client_id`),
  INDEX idx_project (`project_id`),
  INDEX idx_vendor (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- EMAIL LIST ENTRIES
CREATE TABLE IF NOT EXISTS `email_list_entries` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `list_id` INT NOT NULL,
  `email` VARCHAR(254) NOT NULL,
  `name` VARCHAR(200) NULL,
  `metadata_json` JSON NULL,
  `country` CHAR(2) NULL,
  `source` VARCHAR(100) NULL,
  `status` ENUM('active','unsubscribed','bounced','invalid') DEFAULT 'active',
  `is_unsubscribed` TINYINT(1) DEFAULT 0,
  `dedupe_hash` CHAR(40) NOT NULL,
  `added_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `last_emailed_at` DATETIME NULL,
  `total_emails_sent` INT DEFAULT 0,
  UNIQUE KEY uk_list_dedupe (`list_id`, `dedupe_hash`),
  INDEX idx_list (`list_id`),
  INDEX idx_email (`email`),
  INDEX idx_unsub (`is_unsubscribed`),
  INDEX idx_country (`country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- EMAIL TEMPLATES
CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) NOT NULL,
  `subject` VARCHAR(300) NOT NULL,
  `html_body` TEXT NOT NULL,
  `is_default` TINYINT(1) DEFAULT 0,
  `created_by` INT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- EMAIL CAMPAIGNS
CREATE TABLE IF NOT EXISTS `email_campaigns` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `project_id` INT NOT NULL,
  `vendor_id` INT NOT NULL,
  `template_id` INT NULL,
  `name` VARCHAR(200) NOT NULL,
  `subject` VARCHAR(300) NOT NULL,
  `html_body` TEXT NOT NULL,
  `from_name` VARCHAR(150) NULL,
  `from_email` VARCHAR(150) NULL,
  `daily_limit` INT DEFAULT 1000,
  `total_limit` INT DEFAULT 0,
  `sent_count` INT DEFAULT 0,
  `delivered_count` INT DEFAULT 0,
  `opened_count` INT DEFAULT 0,
  `clicked_count` INT DEFAULT 0,
  `converted_count` INT DEFAULT 0,
  `bounced_count` INT DEFAULT 0,
  `unsubscribed_count` INT DEFAULT 0,
  `failed_count` INT DEFAULT 0,
  `status` ENUM('draft','scheduled','running','paused','completed','failed') DEFAULT 'draft',
  `is_multi_step` TINYINT(1) DEFAULT 0,
  `started_at` DATETIME NULL,
  `completed_at` DATETIME NULL,
  `created_by` INT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_project (`project_id`),
  INDEX idx_vendor (`vendor_id`),
  INDEX idx_status (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- EMAIL CAMPAIGN SENDS
CREATE TABLE IF NOT EXISTS `email_campaign_sends` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `campaign_id` INT NOT NULL,
  `project_id` INT NOT NULL,
  `vendor_id` INT NOT NULL,
  `list_id` INT NOT NULL,
  `entry_id` BIGINT NOT NULL,
  `recipient_email` VARCHAR(254) NOT NULL,
  `recipient_name` VARCHAR(200) NULL,
  `country` CHAR(2) NULL,
  `status` ENUM('queued','sent','delivered','opened','clicked','converted','bounced','failed','skipped') DEFAULT 'queued',
  `resend_id` VARCHAR(100) NULL,
  `sent_at` DATETIME NULL,
  `opened_at` DATETIME NULL,
  `clicked_at` DATETIME NULL,
  `converted_at` DATETIME NULL,
  `error_message` TEXT NULL,
  `retry_count` INT DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_campaign_recipient (`campaign_id`, `recipient_email`),
  INDEX idx_campaign (`campaign_id`),
  INDEX idx_list (`list_id`),
  INDEX idx_status (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- CLIENT DOCUMENTS
CREATE TABLE IF NOT EXISTS `client_documents` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `client_id` INT NOT NULL,
  `project_id` INT NULL,
  `document_type` VARCHAR(50) DEFAULT 'Other',
  `original_filename` VARCHAR(255) NOT NULL,
  `stored_filename` VARCHAR(255) NOT NULL,
  `file_size` BIGINT DEFAULT 0,
  `mime_type` VARCHAR(100) NULL,
  `uploaded_by` INT NULL,
  `notes` TEXT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_client (`client_id`),
  INDEX idx_project (`project_id`),
  INDEX idx_doc_type (`document_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- SCHEDULED REPORTS
CREATE TABLE IF NOT EXISTS `scheduled_reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `owner_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `report_type` VARCHAR(50) DEFAULT 'overview',
  `group_by` VARCHAR(50) DEFAULT 'project',
  `filters_json` JSON NULL,
  `frequency` ENUM('daily','weekly','monthly','custom_cron') DEFAULT 'daily',
  `custom_cron` VARCHAR(50) NULL,
  `recipients_csv` TEXT NULL,
  `last_run_at` DATETIME NULL,
  `next_run_at` DATETIME NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_owner (`owner_id`),
  INDEX idx_next_run (`next_run_at`),
  INDEX idx_active (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- VENDOR PORTAL USERS
CREATE TABLE IF NOT EXISTS `vendor_portal_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `global_vendor_id` INT NOT NULL UNIQUE,
  `email` VARCHAR(150) NOT NULL,
  `password_hash` VARCHAR(255) NULL,
  `reset_token` VARCHAR(255) NULL,
  `reset_expires_at` DATETIME NULL,
  `magic_token` VARCHAR(255) NULL,
  `magic_expires_at` DATETIME NULL,
  `last_login_at` DATETIME NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Done.
-- If any ALTER says "duplicate column", that means it already exists.
-- Uncheck "Stop execution on error" and continue.
-- ============================================================
