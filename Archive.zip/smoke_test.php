<?php
/**
 * TRACK FLOW — Smoke test (Phase 9, hardening #7)
 * Verifies config loads, DB connects, helpers exist, constants are seeded,
 * and the latest migration columns/tables are present.
 *
 * Harden this page: place it outside webroot OR protect it. The shipped
 * version returns 403 unless run from CLI or an allowed IP list.
 */

// CLI guard + IP allowlist
$allowed_ips = []; // e.g. ['203.0.113.10']
if (PHP_SAPI !== 'cli') {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    if (!in_array($ip, $allowed_ips, true)) {
        http_response_code(403);
        die('Forbidden');
    }
}

$results = [];
$fail = 0;

function smoke_check(&$results, &$fail, $label, $ok, $detail = '') {
    $results[] = ['label' => $label, 'ok' => (bool)$ok, 'detail' => $detail];
    if (!$ok) $fail++;
}

// 1. config loads
try {
    require_once __DIR__ . '/config.php';
    smoke_check($results, $fail, 'config.php loads', true);
} catch (Throwable $e) {
    smoke_check($results, $fail, 'config.php loads', false, $e->getMessage());
    output($results, $fail);
}

// 2. DB connection
try {
    $pdo->query('SELECT 1');
    smoke_check($results, $fail, 'DB connection', true, DB_HOST . '/' . DB_NAME);
} catch (Throwable $e) {
    smoke_check($results, $fail, 'DB connection', false, $e->getMessage());
}

// 3. Helper functions exist
$helpers = ['sanitize','generate_click_id','audit_log','lookup_country','detect_browser','detect_os','calc_ccr','paginate','get_setting','set_setting','check_rate_limit','email_dedupe','upsert_list_entries'];
foreach ($helpers as $fn) {
    smoke_check($results, $fail, "function {$fn}()", function_exists($fn));
}

// 4. TF_* constant arrays seeded
foreach (['TF_VERTICALS','TF_CONVERSION_TYPES','TF_TARGET_DEVICES','TF_CAMPAIGN_STATUS','TF_VISIBILITY','TF_CAMPAIGN_TYPES','TF_TRAFFIC_TYPES','TF_VENDOR_STATUSES','TF_CURRENCIES','TF_DOCUMENT_TYPES'] as $arr) {
    smoke_check($results, $fail, "\$GLOBALS['{$arr}']", isset($GLOBALS[$arr]) && count($GLOBALS[$arr]) >= 1);
}

// 5. Migration applied — key tables
$required_tables = ['short_links','campaign_geo','campaign_notes','audit_logs','email_lists','email_list_entries','client_documents','scheduled_reports','global_vendors','project_vendor','vendor_portal_users','rate_limits'];
$existing = [];
foreach ($pdo->query("SHOW TABLES") as $row) {
    $existing[] = array_values($row)[0];
}
foreach ($required_tables as $t) {
    smoke_check($results, $fail, "table {$t}", in_array($t, $existing, true));
}

// 6. Migration applied — key columns
$col_checks = [
    ['projects', 'short_code'], ['projects', 'campaign_status'], ['projects', 'daily_cap'],
    ['clicks', 'sub1'], ['clicks', 'browser'], ['clicks', 'country_code'], ['clicks', 'isp'],
    ['conversions', 'approval_status'], ['conversions', 'transaction_id'],
    ['short_links', 'vendor_id'],
    ['sent_emails', 'batch_id'], ['sent_emails', 'retry_count'],
];
$col_stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
foreach ($col_checks as [$table, $col]) {
    $col_stmt->execute([$table, $col]);
    smoke_check($results, $fail, "column {$table}.{$col}", (int)$col_stmt->fetch()['c'] === 1);
}

// 7. Settings seeded
$settings_needed = ['global_postback_enabled','ip_enrichment_enabled','vendor_login_enabled','global_postback_url','strict_target_device'];
$set_stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM settings WHERE setting_key = ?");
foreach ($settings_needed as $sk) {
    $set_stmt->execute([$sk]);
    smoke_check($results, $fail, "setting {$sk}", (int)$set_stmt->fetch()['c'] === 1);
}

function output($results, $fail) {
    if (PHP_SAPI === 'cli') {
        foreach ($results as $r) {
            echo ($r['ok'] ? 'PASS' : 'FAIL') . "  {$r['label']}" . ($r['detail'] ? "  ({$r['detail']})" : '') . PHP_EOL;
        }
        echo PHP_EOL . ($fail === 0 ? 'ALL CHECKS PASSED' : "{$fail} CHECK(S) FAILED") . PHP_EOL;
        exit($fail === 0 ? 0 : 1);
    }
    header('Content-Type: text/plain; charset=utf-8');
    foreach ($results as $r) {
        echo ($r['ok'] ? 'PASS' : 'FAIL') . "  {$r['label']}" . ($r['detail'] ? "  ({$r['detail']})" : '') . PHP_EOL;
    }
    echo PHP_EOL . ($fail === 0 ? 'ALL CHECKS PASSED' : "{$fail} CHECK(S) FAILED") . PHP_EOL;
    exit;
}

output($results, $fail);
