<?php
require_once __DIR__ . '/config.php';
require_login();

$user = current_user();

// ─── Fetch Stats ───
$today = date('Y-m-d');

// Active projects
$stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM projects WHERE status = 'live'");
$stmt->execute();
$active_projects = $stmt->fetch()['cnt'];

// Clicks today
$stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM clicks WHERE DATE(clicked_at) = ?");
$stmt->execute([$today]);
$clicks_today = $stmt->fetch()['cnt'];

// Completes today
$stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM conversions WHERE DATE(converted_at) = ? AND status = 'complete'");
$stmt->execute([$today]);
$completes_today = $stmt->fetch()['cnt'];

// Revenue today
$stmt = $pdo->prepare("SELECT COALESCE(SUM(client_revenue), 0) as total FROM conversions WHERE DATE(converted_at) = ? AND status = 'complete'");
$stmt->execute([$today]);
$revenue_today = $stmt->fetch()['total'];

// Cost today
$stmt = $pdo->prepare("SELECT COALESCE(SUM(vendor_cost), 0) as total FROM conversions WHERE DATE(converted_at) = ? AND status = 'complete'");
$stmt->execute([$today]);
$cost_today = $stmt->fetch()['total'];

$profit_today = $revenue_today - $cost_today;

// ─── Recent Projects ───
$stmt = $pdo->prepare("
    SELECT p.*, c.client_name
    FROM projects p
    LEFT JOIN clients c ON p.client_id = c.id
    ORDER BY p.updated_at DESC
    LIMIT 10
");
$stmt->execute();
$recent_projects = $stmt->fetchAll();

// ─── Chart Data: Last 7 days — single queries ───
$chart_labels = [];
$chart_clicks = [];
$chart_conversions = [];

$chart_click_data = [];
$chart_conv_data = [];

$cc_stmt = $pdo->prepare("SELECT DATE(clicked_at) as d, COUNT(*) as cnt FROM clicks WHERE clicked_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(clicked_at)");
$cc_stmt->execute();
while ($row = $cc_stmt->fetch()) { $chart_click_data[$row['d']] = $row['cnt']; }

$ccv_stmt = $pdo->prepare("SELECT DATE(converted_at) as d, COUNT(*) as cnt FROM conversions WHERE status = 'complete' AND converted_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(converted_at)");
$ccv_stmt->execute();
while ($row = $ccv_stmt->fetch()) { $chart_conv_data[$row['d']] = $row['cnt']; }

for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $chart_labels[] = date('M d', strtotime($d));
    $chart_clicks[] = $chart_click_data[$d] ?? 0;
    $chart_conversions[] = $chart_conv_data[$d] ?? 0;
}

// ─── CCR for today ───
$ccr_today = calc_ccr($completes_today, $clicks_today);

$page_title = 'Dashboard';
require_once __DIR__ . '/helpers/layout_header.php';
?>

<!-- Stats Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 flex items-start justify-between group hover:shadow-md transition-shadow">
        <div>
            <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-1">Active Projects</div>
            <div class="text-3xl font-bold text-slate-800"><?php echo number_format($active_projects); ?></div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl group-hover:scale-110 group-hover:bg-indigo-100 transition-all">
            <i class="bi bi-folder2-open"></i>
        </div>
    </div>
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 flex items-start justify-between group hover:shadow-md transition-shadow">
        <div>
            <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-1">Clicks Today</div>
            <div class="text-3xl font-bold text-slate-800"><?php echo number_format($clicks_today); ?></div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl group-hover:scale-110 group-hover:bg-blue-100 transition-all">
            <i class="bi bi-cursor-fill"></i>
        </div>
    </div>
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 flex items-start justify-between group hover:shadow-md transition-shadow">
        <div>
            <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-1">Completes Today</div>
            <div class="text-3xl font-bold text-slate-800"><?php echo number_format($completes_today); ?></div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl group-hover:scale-110 group-hover:bg-emerald-100 transition-all">
            <i class="bi bi-check-circle-fill"></i>
        </div>
    </div>
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 flex items-start justify-between group hover:shadow-md transition-shadow">
        <div>
            <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-1">Revenue Today</div>
            <div class="text-3xl font-bold text-slate-800"><?php echo format_currency($revenue_today); ?></div>
        </div>
        <div class="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl group-hover:scale-110 group-hover:bg-amber-100 transition-all">
            <i class="bi bi-currency-dollar"></i>
        </div>
    </div>
</div>

<!-- Profit Summary -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">Total Cost Today</div>
        <div class="text-2xl font-bold text-red-600"><?php echo format_currency($cost_today); ?></div>
    </div>
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">Gross Profit Today</div>
        <div class="text-2xl font-bold text-<?php echo $profit_today >= 0 ? 'emerald' : 'red'; ?>-600">
            <?php echo format_currency($profit_today); ?>
        </div>
    </div>
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-2">CCR Today</div>
        <div class="text-2xl font-bold">
            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold bg-<?php echo ccr_color($ccr_today) === 'success' ? 'emerald' : (ccr_color($ccr_today) === 'danger' ? 'red' : 'amber'); ?>-100 text-<?php echo ccr_color($ccr_today) === 'success' ? 'emerald' : (ccr_color($ccr_today) === 'danger' ? 'red' : 'amber'); ?>-800">
                <?php echo $ccr_today; ?>%
            </span>
        </div>
    </div>
</div>

<!-- Chart & Recent Projects -->
<div class="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
    
    <!-- Chart -->
    <div class="xl:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
        <div class="px-6 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <h3 class="text-base font-semibold text-slate-800">Clicks & Conversions</h3>
            <span class="text-xs font-medium text-slate-500 px-2.5 py-1 bg-white border border-slate-200 rounded-lg">Last 7 Days</span>
        </div>
        <div class="p-6 flex-1">
            <div class="relative h-72 w-full">
                <canvas id="dashboardChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Quick List -->
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
        <div class="px-6 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <h3 class="text-base font-semibold text-slate-800">Recent Projects</h3>
            <a href="<?php echo BASE_URL; ?>/projects/list.php" class="text-sm font-medium text-indigo-600 hover:text-indigo-700">View All</a>
        </div>
        <div class="divide-y divide-slate-100 overflow-y-auto max-h-[350px]">
            <?php if (empty($recent_projects)): ?>
                <div class="p-8 text-center">
                    <p class="text-sm text-slate-500 mb-4">No projects yet.</p>
                    <a href="<?php echo BASE_URL; ?>/projects/create.php" class="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-indigo-700 bg-indigo-100 hover:bg-indigo-200">
                        Create Project
                    </a>
                </div>
            <?php else: ?>
                <?php foreach (array_slice($recent_projects, 0, 5) as $p): ?>
                <div class="p-5 hover:bg-slate-50 transition-colors flex items-center justify-between">
                    <div>
                        <a href="<?php echo BASE_URL; ?>/projects/detail.php?id=<?php echo $p['id']; ?>" class="text-sm font-semibold text-slate-800 hover:text-indigo-600 block mb-0.5">
                            <?php echo sanitize($p['project_name']); ?>
                        </a>
                        <div class="flex items-center gap-2 text-xs text-slate-500">
                            <span class="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-slate-600"><?php echo sanitize($p['project_code']); ?></span>
                            <span>&bull;</span>
                            <span><?php echo sanitize($p['client_name'] ?? '-'); ?></span>
                        </div>
                    </div>
                    <div>
                        <?php echo status_badge($p['status']); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
$chart_labels_json = json_encode($chart_labels);
$chart_clicks_json = json_encode($chart_clicks);
$chart_conv_json = json_encode($chart_conversions);

$extra_js = <<<EOT
<script>
Chart.defaults.font.family = "'Inter', sans-serif";
Chart.defaults.color = '#64748b';

new Chart(document.getElementById('dashboardChart'), {
    type: 'bar',
    data: {
        labels: {$chart_labels_json},
        datasets: [
            {
                label: 'Clicks',
                data: {$chart_clicks_json},
                backgroundColor: 'rgba(99, 102, 241, 0.85)',
                hoverBackgroundColor: 'rgba(79, 70, 229, 1)',
                borderRadius: 4,
                borderSkipped: false,
                barPercentage: 0.6,
                categoryPercentage: 0.8
            },
            {
                label: 'Conversions',
                data: {$chart_conv_json},
                backgroundColor: 'rgba(16, 185, 129, 0.85)',
                hoverBackgroundColor: 'rgba(5, 150, 105, 1)',
                borderRadius: 4,
                borderSkipped: false,
                barPercentage: 0.6,
                categoryPercentage: 0.8
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { 
            legend: { 
                position: 'top',
                align: 'end',
                labels: { usePointStyle: true, boxWidth: 8, padding: 20 }
            },
            tooltip: {
                backgroundColor: 'rgba(15, 23, 42, 0.9)',
                titleFont: { size: 13, weight: '600' },
                bodyFont: { size: 13 },
                padding: 12,
                cornerRadius: 8,
                displayColors: false
            }
        },
        scales: { 
            y: { 
                beginAtZero: true, 
                ticks: { precision: 0 },
                grid: { color: '#f1f5f9', drawBorder: false }
            },
            x: { 
                grid: { display: false, drawBorder: false }
            }
        },
        interaction: {
            intersect: false,
            mode: 'index',
        },
    }
});
</script>
EOT;

require_once __DIR__ . '/helpers/layout_footer.php';
?>
