<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

$project_id = intval($_GET['project_id'] ?? 0);
if (!$project_id) redirect(BASE_URL . '/projects/list.php');

$stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
$stmt->execute([$project_id]);
$project = $stmt->fetch();
if (!$project) {
    set_flash('danger', 'Project not found.');
    redirect(BASE_URL . '/projects/list.php');
}

// Fetch vendors
$vendors = $pdo->prepare("SELECT * FROM vendors WHERE project_id = ? ORDER BY vendor_name");
$vendors->execute([$project_id]);
$vendors = $vendors->fetchAll();

// ─── Handle POST ───
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect(BASE_URL . '/tracking/manual.php?project_id=' . $project_id);
    }

    $vendor_id = intval($_POST['vendor_id'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    $custom_click_id = trim($_POST['click_id'] ?? '');

    if (!$vendor_id || empty($reason)) {
        set_flash('danger', 'Vendor and reason are required.');
        redirect(BASE_URL . '/tracking/manual.php?project_id=' . $project_id);
    }

    // Use existing click_id or generate new one
    $click_id = $custom_click_id ?: bin2hex(random_bytes(16));

    // If using existing click_id, verify it exists and isn't converted
    if ($custom_click_id) {
        $check = $pdo->prepare("SELECT * FROM clicks WHERE click_id = ?");
        $check->execute([$click_id]);
        $existing = $check->fetch();

        if ($existing) {
            if ($existing['is_converted']) {
                set_flash('danger', 'This click is already converted.');
                redirect(BASE_URL . '/tracking/manual.php?project_id=' . $project_id);
            }
            $vendor_id = $existing['vendor_id']; // Use the original vendor
        }
    }

    // Get vendor CPI (validate vendor belongs to project)
    $vstmt = $pdo->prepare("SELECT vendor_cpi FROM vendors WHERE id = ? AND project_id = ?");
    $vstmt->execute([$vendor_id, $project_id]);
    $vendor = $vstmt->fetch();

    if (!$vendor) {
        set_flash('danger', 'Vendor not found or does not belong to this project.');
        redirect(BASE_URL . '/tracking/manual.php?project_id=' . $project_id);
    }

    $revenue = $project['client_cpi'];
    $cost = $vendor['vendor_cpi'];
    $profit = $revenue - $cost;

    // Create click record if new
    if (!$custom_click_id) {
        $pdo->prepare("INSERT INTO clicks (click_id, project_id, vendor_id, ip_address, user_agent, is_converted) VALUES (?, ?, ?, 'manual', 'manual', 1)")
            ->execute([$click_id, $project_id, $vendor_id]);
        $pdo->prepare("UPDATE projects SET clicks_count = clicks_count + 1 WHERE id = ?")->execute([$project_id]);
    } else {
        // Mark existing click as converted
        $pdo->prepare("UPDATE clicks SET is_converted = 1 WHERE click_id = ?")->execute([$click_id]);
    }

    // Record conversion
    $pdo->prepare("INSERT INTO conversions (click_id, project_id, vendor_id, status, client_revenue, vendor_cost, profit, is_manual) VALUES (?, ?, ?, 'complete', ?, ?, ?, 1)")
        ->execute([$click_id, $project_id, $vendor_id, $revenue, $cost, $profit]);

    // Update project completes
    $pdo->prepare("UPDATE projects SET completes_count = completes_count + 1 WHERE id = ?")->execute([$project_id]);

    // Check quota
    if ($project['total_quota'] > 0) {
        $count_stmt = $pdo->prepare("SELECT completes_count FROM projects WHERE id = ?");
        $count_stmt->execute([$project_id]);
        $new_count = $count_stmt->fetch()['completes_count'];

        if ($new_count >= $project['total_quota']) {
            $pdo->prepare("UPDATE projects SET status = 'hold' WHERE id = ?")->execute([$project_id]);
            $pdo->prepare("UPDATE vendors SET status = 'paused' WHERE project_id = ? AND status = 'active'")->execute([$project_id]);
        }
    }

    // Log
    $pdo->prepare("INSERT INTO logs (log_type, project_id, vendor_id, click_id, status, message) VALUES (?, ?, ?, ?, ?, ?)")
        ->execute(['manual', $project_id, $vendor_id, $click_id, 'success', 'Manual conversion: ' . $reason]);

    regenerate_csrf_token();
    set_flash('success', 'Manual conversion recorded.');
    redirect(BASE_URL . '/projects/detail.php?id=' . $project_id);
}

$page_title = 'Manual Conversion';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<div class="mb-6">
    <a href="<?php echo BASE_URL; ?>/projects/detail.php?id=<?php echo $project_id; ?>" class="text-decoration-none">
        <i class="bi bi-arrow-left me-1"></i>Back to Project
    </a>
</div>

<div class="flex flex-wrap -mx-3 justify-center">
    <div class="col-lg-6">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header">
                <h6 class="mb-0 font-semibold">Record Manual Conversion</h6>
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div class="p-4 mb-4 text-sm text-cyan-800 rounded-lg bg-cyan-50 small">
                    <i class="bi bi-info-circle me-1"></i>
                    Manual conversions are flagged in the system and displayed separately in reports.
                </div>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-6">
                        <label for="vendor_id" class="block text-sm font-medium text-slate-700 mb-1">Vendor <span class="text-red-600">*</span></label>
                        <select class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white" id="vendor_id" name="vendor_id" required>
                            <option value="">Select Vendor</option>
                            <?php foreach ($vendors as $v): ?>
                            <option value="<?php echo $v['id']; ?>"><?php echo sanitize($v['vendor_name']); ?> (CPI: <?php echo format_currency($v['vendor_cpi']); ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-6">
                        <label for="click_id" class="block text-sm font-medium text-slate-700 mb-1">Click ID <small class="text-slate-500">(optional)</small></label>
                        <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border font-monospace" id="click_id" name="click_id"
                               placeholder="Leave blank to auto-generate">
                        <small class="text-slate-500">Enter an existing click_id to convert it, or leave blank.</small>
                    </div>
                    <div class="mb-6">
                        <label for="reason" class="block text-sm font-medium text-slate-700 mb-1">Reason <span class="text-red-600">*</span></label>
                        <textarea class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="reason" name="reason" rows="3"
                                  placeholder="Why is this being recorded manually?" required></textarea>
                    </div>
                    <div class="flex gap-2">
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors"><i class="bi bi-check-lg me-1"></i>Record Conversion</button>
                        <a href="<?php echo BASE_URL; ?>/projects/detail.php?id=<?php echo $project_id; ?>" class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
