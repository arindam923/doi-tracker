<?php
require_once __DIR__ . '/config.php';

// If already logged in, go to dashboard
if (is_logged_in()) {
    redirect(BASE_URL . '/dashboard.php');
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — <?php echo SITE_NAME; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: { primary: '#4f46e5' }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center font-sans antialiased selection:bg-indigo-500 selection:text-white relative overflow-hidden">

    <!-- Decorative background elements -->
    <div class="absolute top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
        <div class="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-indigo-500/10 blur-3xl"></div>
        <div class="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-emerald-500/10 blur-3xl"></div>
    </div>

    <div class="w-full max-w-md px-6">
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-indigo-600 text-white shadow-xl shadow-indigo-600/20 mb-6">
                <i class="bi bi-lightning-charge-fill text-3xl"></i>
            </div>
            <h1 class="text-3xl font-bold text-slate-900 tracking-tight"><?php echo SITE_NAME; ?></h1>
            <p class="text-slate-500 mt-2 text-sm font-medium uppercase tracking-wide">DOI Registration & Tracking Platform</p>
        </div>

        <?php if ($flash): 
            $alertClass = match($flash['type']) {
                'success' => 'bg-emerald-50 text-emerald-800 border-emerald-200',
                'danger' => 'bg-red-50 text-red-800 border-red-200',
                'warning' => 'bg-amber-50 text-amber-800 border-amber-200',
                'info' => 'bg-blue-50 text-blue-800 border-blue-200',
                default => 'bg-slate-50 text-slate-800 border-slate-200'
            };
        ?>
        <div class="mb-6 p-4 rounded-xl border flex justify-between items-start shadow-sm <?php echo $alertClass; ?>" role="alert" id="flash-alert">
            <div class="text-sm font-medium"><?php echo htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <button type="button" class="text-current opacity-60 hover:opacity-100 transition-opacity" onclick="document.getElementById('flash-alert').remove()">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <?php endif; ?>

        <div class="bg-white rounded-2xl shadow-xl shadow-slate-200/50 border border-slate-100 overflow-hidden">
            <div class="p-8">
                <h5 class="text-xl font-semibold text-slate-800 mb-6">Sign In</h5>
                
                <form method="POST" action="<?php echo BASE_URL; ?>/auth.php" class="space-y-5">
                    <?php echo csrf_field(); ?>
                    
                    <div>
                        <label for="username" class="block text-sm font-medium text-slate-700 mb-1.5">Username</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                                <i class="bi bi-person text-lg"></i>
                            </div>
                            <input type="text" id="username" name="username" placeholder="Enter your username" required autofocus
                                class="block w-full pl-10 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white transition-colors text-slate-900 outline-none placeholder:text-slate-400">
                        </div>
                    </div>
                    
                    <div>
                        <label for="password" class="block text-sm font-medium text-slate-700 mb-1.5">Password</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                                <i class="bi bi-lock text-lg"></i>
                            </div>
                            <input type="password" id="password" name="password" placeholder="Enter your password" required
                                class="block w-full pl-10 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white transition-colors text-slate-900 outline-none placeholder:text-slate-400">
                        </div>
                    </div>
                    
                    <button type="submit" class="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all mt-6">
                        <i class="bi bi-box-arrow-in-right"></i> Sign In
                    </button>
                </form>
            </div>
        </div>
        
        <p class="text-center text-slate-400 mt-8 text-xs font-medium">v1.0 &mdash; <?php echo date('Y'); ?></p>
    </div>
</body>
</html>
