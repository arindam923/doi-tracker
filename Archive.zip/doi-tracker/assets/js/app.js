/**
 * Ternfluenzy — Client-side JavaScript Helpers
 */

// ─── Clipboard Copy ───
function copyToClipboard(text, btn) {
    navigator.clipboard.writeText(text).then(() => {
        const originalHTML = btn.innerHTML;
        btn.innerHTML = '<i class="bi bi-check-lg text-success"></i>';
        btn.classList.add('copied');
        setTimeout(() => {
            btn.innerHTML = originalHTML;
            btn.classList.remove('copied');
        }, 2000);
    }).catch(() => {
        // Fallback for older browsers
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);

        const originalHTML = btn.innerHTML;
        btn.innerHTML = '<i class="bi bi-check-lg text-success"></i>';
        btn.classList.add('copied');
        setTimeout(() => {
            btn.innerHTML = originalHTML;
            btn.classList.remove('copied');
        }, 2000);
    });
}

// ─── Confirmation Dialog ───
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// ─── Toast Notification ───
function showToast(type, message) {
    let container = document.querySelector('.tf-toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'tf-toast-container fixed top-4 right-4 z-[9999] flex flex-col gap-2';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    const typeClasses = {
        'success': 'bg-emerald-50 text-emerald-800 border-emerald-200',
        'danger': 'bg-red-50 text-red-800 border-red-200',
        'warning': 'bg-amber-50 text-amber-800 border-amber-200',
        'info': 'bg-blue-50 text-blue-800 border-blue-200',
    };
    const toastClass = typeClasses[type] || 'bg-slate-50 text-slate-800 border-slate-200';

    toast.className = `p-4 rounded-lg border shadow-lg flex justify-between items-start min-w-[300px] transition-all duration-300 transform translate-x-full ${toastClass}`;
    toast.innerHTML = `
        <div class="text-sm font-medium">${message}</div>
        <button type="button" class="text-current opacity-70 hover:opacity-100 ml-4" onclick="this.parentElement.remove()">
            <i class="bi bi-x-lg"></i>
        </button>
    `;

    container.appendChild(toast);
    
    // Animate in
    setTimeout(() => {
        toast.classList.remove('translate-x-full');
    }, 10);

    // Auto dismiss
    setTimeout(() => {
        toast.classList.add('translate-x-full', 'opacity-0');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// ─── Mobile Sidebar Toggle ───
function toggleSidebar() {
    document.querySelector('.tf-sidebar').classList.toggle('show');
}

// ─── Chart.js Helper ───
function createLineChart(canvasId, labels, datasets, options = {}) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return null;

    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'top' },
        },
        scales: {
            y: { beginAtZero: true, ticks: { precision: 0 } },
        },
    };

    return new Chart(ctx, {
        type: options.type || 'line',
        data: { labels, datasets },
        options: { ...defaultOptions, ...options },
    });
}

// ─── Form Validation ───
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return true;

    const requiredFields = form.querySelectorAll('[required]');
    let valid = true;

    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            valid = false;
        } else {
            field.classList.remove('is-invalid');
        }
    });

    return valid;
}

// ─── Initialize on DOM Ready ───
document.addEventListener('DOMContentLoaded', () => {
    // Auto-dismiss alerts after 5s
    document.querySelectorAll('.alert-dismissible').forEach(alert => {
        setTimeout(() => {
            alert.classList.remove('show');
            setTimeout(() => alert.remove(), 300);
        }, 5000);
    });

    // Copy buttons
    document.querySelectorAll('[data-copy]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            copyToClipboard(btn.dataset.copy, btn);
        });
    });

    // Confirm dialogs
    document.querySelectorAll('[data-confirm]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            if (!confirm(btn.dataset.confirm)) {
                e.preventDefault();
            }
        });
    });
});
