<?php
require_once __DIR__ . '/../config.php';
require_login();

$from_date = sanitize($_GET['from'] ?? date('Y-m-d', strtotime('-30 days')));
$to_date   = sanitize($_GET['to'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from_date)) $from_date = date('Y-m-d', strtotime('-30 days'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to_date)) $to_date = date('Y-m-d');
$project_filter = intval($_GET['project_id'] ?? 0);

// ─── Per-Vendor Traffic Summary ───
$sql = "SELECT v.id, v.vendor_name, v.vendor_cpi, v.status, p.project_code,
        COUNT(cl.id) as total_clicks,
        SUM(cl.is_converted) as total_converts,
        COALESCE(SUM(cv.client_revenue),0) as revenue,
        COALESCE(SUM(cv.vendor_cost),0) as cost,
        COALESCE(SUM(cv.profit),0) as profit
        FROM vendors v
        JOIN projects p ON v.project_id = p.id
        LEFT JOIN clicks cl ON cl.vendor_id = v.id AND cl.clicked_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY)
        LEFT JOIN conversions cv ON cv.vendor_id = v.id AND cv.status = 'complete' AND cv.converted_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY)
        WHERE 1=1";
$params = [$from_date, $to_date, $from_date, $to_date];

if ($project_filter) {
    $sql .= " AND v.project_id = ?";
    $params[] = $project_filter;
}

$sql .= " GROUP BY v.id ORDER BY total_clicks DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$vendor_traffic = $stmt->fetchAll();

// Projects for filter
$projects_list = $pdo->query("SELECT id, project_code, project_name FROM projects ORDER BY project_name")->fetchAll();

$page_title = 'Traffic Summary';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<!-- Filters -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6 py-2">
        <form method="GET" class="flex flex-wrap -mx-3 g-2 align-items-end">
            <div class="col-md-2">
                <label class="block text-sm font-medium text-slate-700 mb-1 small">From</label>
                <input type="date" name="from" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm" value="<?php echo $from_date; ?>">
            </div>
            <div class="col-md-2">
                <label class="block text-sm font-medium text-slate-700 mb-1 small">To</label>
                <input type="date" name="to" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm" value="<?php echo $to_date; ?>">
            </div>
            <div class="col-md-3">
                <label class="block text-sm font-medium text-slate-700 mb-1 small">Project</label>
                <select name="project_id" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white-sm">
                    <option value="">All Projects</option>
                    <?php foreach ($projects_list as $p): ?>
                    <option value="<?php echo $p['id']; ?>" <?php echo $project_filter == $p['id'] ? 'selected' : ''; ?>>
                        <?php echo sanitize($p['project_code'] . ' — ' . $p['project_name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-1 px-3 rounded-lg text-sm shadow-sm transition-colors w-100">Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Traffic Table -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header">
        <h6 class="mb-0 font-semibold">Vendor Traffic Summary</h6>
        <span class="text-slate-500 small"><?php echo $from_date; ?> to <?php echo $to_date; ?></span>
    </div>
    <div class="overflow-x-auto w-full">
        <table class="min-w-full text-left border-collapse mb-0">
            <thead>
                <tr>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Vendor</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Project</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">CPI</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Clicks</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Completes</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">CCR</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Revenue</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Cost</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Profit</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($vendor_traffic)): ?>
                <tr><td colspan="10" class="text-center text-slate-500 py-4">No traffic data in this period.</td></tr>
                <?php else: ?>
                <?php foreach ($vendor_traffic as $vt): ?>
                <?php $ccr = calc_ccr($vt['total_converts'], $vt['total_clicks']); ?>
                <tr>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><strong><?php echo sanitize($vt['vendor_name']); ?></strong></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><code><?php echo sanitize($vt['project_code']); ?></code></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo format_currency($vt['vendor_cpi']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo number_format($vt['total_clicks']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo number_format($vt['total_converts']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><span class="badge bg-<?php echo ccr_color($ccr); ?>"><?php echo $ccr; ?>%</span></td>
                    <td class="text-emerald-600"><?php echo format_currency($vt['revenue']); ?></td>
                    <td class="text-red-600"><?php echo format_currency($vt['cost']); ?></td>
                    <td class="text-<?php echo $vt['profit'] >= 0 ? 'success' : 'danger'; ?>"><?php echo format_currency($vt['profit']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo status_badge($vt['status']); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
