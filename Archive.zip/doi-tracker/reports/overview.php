<?php
require_once __DIR__ . '/../config.php';
require_login();

// ─── Filters ───
$from_date = sanitize($_GET['from'] ?? date('Y-m-d', strtotime('-30 days')));
$to_date   = sanitize($_GET['to'] ?? date('Y-m-d'));
// Validate date format
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from_date)) $from_date = date('Y-m-d', strtotime('-30 days'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to_date)) $to_date = date('Y-m-d');
$project_filter = intval($_GET['project_id'] ?? 0);

// ─── Summary Stats ───
$where_date = "AND c.converted_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY)";
$params_date = [$from_date, $to_date];

// Overall totals
$sql = "SELECT COUNT(*) as cnt, COALESCE(SUM(client_revenue),0) as revenue, COALESCE(SUM(vendor_cost),0) as cost, COALESCE(SUM(profit),0) as profit FROM conversions c WHERE c.status = 'complete' $where_date";
if ($project_filter) {
    $sql .= " AND c.project_id = ?";
    $params_date[] = $project_filter;
}
$stmt = $pdo->prepare($sql);
$stmt->execute($params_date);
$totals = $stmt->fetch();

$profit_margin = $totals['revenue'] > 0 ? round(($totals['profit'] / $totals['revenue']) * 100, 1) : 0;

// Clicks in period
$sql = "SELECT COUNT(*) as cnt FROM clicks WHERE clicked_at BETWEEN ? AND DATE_ADD(?, INTERVAL 1 DAY)";
$params_clicks = [$from_date, $to_date];
if ($project_filter) {
    $sql .= " AND project_id = ?";
    $params_clicks[] = $project_filter;
}
$stmt = $pdo->prepare($sql);
$stmt->execute($params_clicks);
$total_clicks = $stmt->fetch()['cnt'];

$ccr = calc_ccr($totals['cnt'], $total_clicks);

// ─── Per-Project Breakdown ───
$sql = "SELECT p.project_code, p.project_name, p.client_cpi,
        COUNT(c.id) as completes, COALESCE(SUM(c.client_revenue),0) as revenue,
        COALESCE(SUM(c.vendor_cost),0) as cost, COALESCE(SUM(c.profit),0) as profit
        FROM conversions c
        JOIN projects p ON c.project_id = p.id
        WHERE c.status = 'complete' $where_date";
$params_proj = $params_date;
if ($project_filter) {
    $sql .= " AND c.project_id = ?";
    $params_proj[] = $project_filter;
}
$sql .= " GROUP BY c.project_id ORDER BY revenue DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params_proj);
$project_breakdown = $stmt->fetchAll();

// ─── Per-Vendor Breakdown ───
$sql = "SELECT v.vendor_name, v.vendor_cpi,
        COUNT(c.id) as completes, COALESCE(SUM(c.client_revenue),0) as revenue,
        COALESCE(SUM(c.vendor_cost),0) as cost, COALESCE(SUM(c.profit),0) as profit
        FROM conversions c
        JOIN vendors v ON c.vendor_id = v.id
        WHERE c.status = 'complete' $where_date";
$params_vend = $params_date;
if ($project_filter) {
    $sql .= " AND c.project_id = ?";
    $params_vend[] = $project_filter;
}
$sql .= " GROUP BY c.vendor_id ORDER BY revenue DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params_vend);
$vendor_breakdown = $stmt->fetchAll();

// ─── Chart Data: Daily Revenue ───
$chart_labels = [];
$chart_revenue = [];
$chart_cost = [];

$period = (strtotime($to_date) - strtotime($from_date)) / 86400;
$interval = $period > 60 ? 7 : 1;

$current = strtotime($from_date);
$end = strtotime($to_date);
while ($current <= $end) {
    $d = date('Y-m-d', $current);
    $chart_labels[] = date('M d', $current);

    $sql = "SELECT COALESCE(SUM(client_revenue),0) as rev, COALESCE(SUM(vendor_cost),0) as cost FROM conversions WHERE status = 'complete' AND DATE(converted_at) = ?";
    $params_d = [$d];
    if ($project_filter) { $sql .= " AND project_id = ?"; $params_d[] = $project_filter; }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params_d);
    $row = $stmt->fetch();
    $chart_revenue[] = (float)$row['rev'];
    $chart_cost[] = (float)$row['cost'];

    $current += 86400 * $interval;
}

// Projects for filter
$projects_list = $pdo->query("SELECT id, project_code, project_name FROM projects ORDER BY project_name")->fetchAll();

$page_title = 'Revenue Report';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<!-- Date Filter -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6 py-2">
        <form method="GET" class="flex flex-wrap -mx-3 g-2 align-items-end">
            <div class="col-md-2">
                <label class="block text-sm font-medium text-slate-700 mb-1 small">From</label>
                <input type="date" name="from" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm" value="<?php echo $from_date; ?>">
            </div>
            <div class="col-md-2">
                <label class="block text-sm font-medium text-slate-700 mb-1 small">To</label>
                <input type="date" name="to" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm" value="<?php echo $to_date; ?>">
            </div>
            <div class="col-md-3">
                <label class="block text-sm font-medium text-slate-700 mb-1 small">Project</label>
                <select name="project_id" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white-sm">
                    <option value="">All Projects</option>
                    <?php foreach ($projects_list as $p): ?>
                    <option value="<?php echo $p['id']; ?>" <?php echo $project_filter == $p['id'] ? 'selected' : ''; ?>>
                        <?php echo sanitize($p['project_code'] . ' — ' . $p['project_name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-1 px-3 rounded-lg text-sm shadow-sm transition-colors w-100">Filter</button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo BASE_URL; ?>/reports/export.php?from=<?php echo $from_date; ?>&to=<?php echo $to_date; ?>&project_id=<?php echo $project_filter; ?>"
                   class="btn btn-sm btn-outline-success w-100"><i class="bi bi-download me-1"></i>Export CSV</a>
            </div>
        </form>
    </div>
</div>

<!-- Summary Cards -->
<div class="flex flex-wrap -mx-3 g-3 mb-6">
    <div class="col-6 col-lg-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">Conversions</div>
            <div class="tf-stat-value"><?php echo number_format($totals['cnt']); ?></div>
        </div>
    </div>
    <div class="col-6 col-lg-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">Clicks</div>
            <div class="tf-stat-value"><?php echo number_format($total_clicks); ?></div>
        </div>
    </div>
    <div class="col-6 col-lg-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">CCR</div>
            <div class="tf-stat-value"><span class="badge bg-<?php echo ccr_color($ccr); ?> fs-6"><?php echo $ccr; ?>%</span></div>
        </div>
    </div>
    <div class="col-6 col-lg-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">Revenue</div>
            <div class="tf-stat-value text-emerald-600"><?php echo format_currency($totals['revenue']); ?></div>
        </div>
    </div>
    <div class="col-6 col-lg-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">Cost</div>
            <div class="tf-stat-value text-red-600"><?php echo format_currency($totals['cost']); ?></div>
        </div>
    </div>
    <div class="col-6 col-lg-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">Profit</div>
            <div class="tf-stat-value text-<?php echo $totals['profit'] >= 0 ? 'success' : 'danger'; ?>">
                <?php echo format_currency($totals['profit']); ?>
                <small class="d-block fs-6 fw-normal"><?php echo $profit_margin; ?>% margin</small>
            </div>
        </div>
    </div>
</div>

<!-- Chart -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header"><h6 class="mb-0 font-semibold">Revenue vs Cost Over Time</h6></div>
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6"><div style="height: 280px;"><canvas id="revenueChart"></canvas></div></div>
</div>

<!-- Per-Project Breakdown -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header"><h6 class="mb-0 font-semibold">Revenue by Project</h6></div>
    <div class="overflow-x-auto w-full">
        <table class="min-w-full text-left border-collapse mb-0">
            <thead>
                <tr><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Project</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Completes</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">CPI</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Revenue</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Cost</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Profit</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Margin</th></tr>
            </thead>
            <tbody>
                <?php if (empty($project_breakdown)): ?>
                <tr><td colspan="7" class="text-center text-slate-500 py-3">No data in this period.</td></tr>
                <?php else: ?>
                <?php foreach ($project_breakdown as $pb): ?>
                <?php $margin = $pb['revenue'] > 0 ? round(($pb['profit'] / $pb['revenue']) * 100, 1) : 0; ?>
                <tr>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><strong><?php echo sanitize($pb['project_code']); ?></strong><br><small class="text-slate-500"><?php echo sanitize($pb['project_name']); ?></small></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo number_format($pb['completes']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo format_currency($pb['client_cpi']); ?></td>
                    <td class="text-emerald-600"><?php echo format_currency($pb['revenue']); ?></td>
                    <td class="text-red-600"><?php echo format_currency($pb['cost']); ?></td>
                    <td class="text-<?php echo $pb['profit'] >= 0 ? 'success' : 'danger'; ?>"><?php echo format_currency($pb['profit']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo $margin; ?>%</td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Per-Vendor Breakdown -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header"><h6 class="mb-0 font-semibold">Revenue by Vendor</h6></div>
    <div class="overflow-x-auto w-full">
        <table class="min-w-full text-left border-collapse mb-0">
            <thead>
                <tr><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Vendor</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Completes</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">CPI</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Revenue</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Cost</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Profit</th><th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Margin</th></tr>
            </thead>
            <tbody>
                <?php if (empty($vendor_breakdown)): ?>
                <tr><td colspan="7" class="text-center text-slate-500 py-3">No data in this period.</td></tr>
                <?php else: ?>
                <?php foreach ($vendor_breakdown as $vb): ?>
                <?php $margin = $vb['revenue'] > 0 ? round(($vb['profit'] / $vb['revenue']) * 100, 1) : 0; ?>
                <tr>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><strong><?php echo sanitize($vb['vendor_name']); ?></strong></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo number_format($vb['completes']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo format_currency($vb['vendor_cpi']); ?></td>
                    <td class="text-emerald-600"><?php echo format_currency($vb['revenue']); ?></td>
                    <td class="text-red-600"><?php echo format_currency($vb['cost']); ?></td>
                    <td class="text-<?php echo $vb['profit'] >= 0 ? 'success' : 'danger'; ?>"><?php echo format_currency($vb['profit']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo $margin; ?>%</td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
$cl_json = json_encode($chart_labels);
$cr_json = json_encode($chart_revenue);
$cc_json = json_encode($chart_cost);

$extra_js = <<<EOT
<script>
new Chart(document.getElementById('revenueChart'), {
    type: 'line',
    data: {
        labels: {$cl_json},
        datasets: [
            { label: 'Revenue', data: {$cr_json}, borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.1)', fill: true, tension: 0.3 },
            { label: 'Cost', data: {$cc_json}, borderColor: '#ef4444', backgroundColor: 'rgba(239,68,68,0.1)', fill: true, tension: 0.3 }
        ]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: true } } }
});
</script>
EOT;

require_once __DIR__ . '/../helpers/layout_footer.php';
?>
