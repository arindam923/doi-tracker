<?php
/**
 * Shared layout: sidebar + topbar
 * Include this at the top of every page after config.php
 */

// Navigation structure
$nav_items = [
    'main' => [
        ['url' => '/dashboard.php', 'icon' => 'bi-speedometer2', 'label' => 'Dashboard'],
    ],
    'management' => [
        ['url' => '/projects/list.php', 'icon' => 'bi-folder2-open', 'label' => 'Projects'],
        ['url' => '/clients/list.php', 'icon' => 'bi-building', 'label' => 'Clients'],
    ],
    'analytics' => [
        ['url' => '/reports/overview.php', 'icon' => 'bi-graph-up', 'label' => 'Revenue Report'],
        ['url' => '/reports/traffic_summary.php', 'icon' => 'bi-bar-chart-line', 'label' => 'Traffic Summary'],
    ],
    'email' => [
        ['url' => '/email/compose.php', 'icon' => 'bi-send', 'label' => 'Send Email'],
        ['url' => '/email/history.php', 'icon' => 'bi-clock-history', 'label' => 'Email History'],
    ],
    'system' => [
        ['url' => '/logs/view.php', 'icon' => 'bi-journal-text', 'label' => 'Logs'],
        ['url' => '/settings/index.php', 'icon' => 'bi-gear', 'label' => 'Settings', 'roles' => ['super_admin']],
        ['url' => '/settings/users.php', 'icon' => 'bi-people', 'label' => 'Users', 'roles' => ['super_admin']],
    ],
];

$current_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

function is_nav_active($url) {
    global $current_path;
    $base = rtrim(parse_url(BASE_URL, PHP_URL_PATH) ?: '', '/');
    $dir = dirname($base . $url);
    return strpos($current_path, $dir . '/') !== false || $current_path === $base . $url;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8') . ' — ' : ''; ?><?php echo htmlspecialchars(SITE_NAME, ENT_QUOTES, 'UTF-8'); ?></title>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: { primary: '#4f46e5' }
                }
            }
        }
    </script>
    
    <style>
        /* Minimal custom styles for elements Tailwind CDN struggles with dynamically */
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .sidebar-transition { transition: transform 0.3s ease-in-out; }
        @media (max-width: 1024px) {
            .sidebar-mobile-hidden { transform: translateX(-100%); }
            .sidebar-mobile-show { transform: translateX(0); }
        }
        /* Custom scrollbar for sidebar */
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }
    </style>
    
    <?php if (isset($extra_head)) echo $extra_head; ?>
</head>
<body class="text-slate-800 antialiased min-h-screen flex">

    <!-- Sidebar -->
    <aside id="sidebar" class="sidebar-transition sidebar-mobile-hidden fixed lg:static inset-y-0 left-0 z-50 w-64 bg-slate-900 text-slate-300 flex flex-col custom-scrollbar overflow-y-auto shrink-0 shadow-xl lg:shadow-none">
        <div class="p-6 sticky top-0 bg-slate-900/95 backdrop-blur z-10 border-b border-slate-800">
            <h4 class="text-white text-xl font-bold flex items-center gap-2">
                <i class="bi bi-lightning-charge-fill text-indigo-500"></i>
                <?php echo SITE_NAME; ?>
            </h4>
            <small class="text-slate-500 text-xs font-medium uppercase tracking-wider block mt-1 ml-6">DOI Tracking Platform</small>
        </div>

        <div class="flex-1 py-4">
            <?php foreach ($nav_items as $section => $items): ?>
            <div class="mb-6">
                <div class="px-6 mb-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    <?php echo ucfirst($section); ?>
                </div>
                <nav class="space-y-1 px-3">
                    <?php foreach ($items as $item): ?>
                        <?php
                        if (isset($item['roles'])) {
                            $user = current_user();
                            if (!$user || !in_array($user['role'], $item['roles'])) continue;
                        }
                        $active = is_nav_active($item['url']);
                        $linkClass = $active 
                            ? 'bg-indigo-600/10 text-indigo-400 border-indigo-500' 
                            : 'border-transparent hover:bg-slate-800 hover:text-white';
                        ?>
                        <a href="<?php echo BASE_URL . $item['url']; ?>"
                           class="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium border-l-4 transition-colors <?php echo $linkClass; ?>">
                            <i class="bi <?php echo $item['icon']; ?> text-lg <?php echo $active ? 'text-indigo-400' : 'text-slate-400'; ?>"></i>
                            <?php echo $item['label']; ?>
                        </a>
                    <?php endforeach; ?>
                </nav>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="p-4 border-t border-slate-800 mt-auto">
            <a href="<?php echo BASE_URL; ?>/auth.php?action=logout" class="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-colors">
                <i class="bi bi-box-arrow-left text-lg"></i> Logout
            </a>
        </div>
    </aside>

    <!-- Overlay for mobile -->
    <div id="sidebar-overlay" class="fixed inset-0 bg-slate-900/50 z-40 hidden lg:hidden" onclick="toggleSidebar()"></div>

    <!-- Main Content -->
    <main class="flex-1 flex flex-col min-w-0 overflow-hidden bg-slate-50 min-h-screen">
        <!-- Topbar -->
        <header class="bg-white border-b border-slate-200 sticky top-0 z-30">
            <div class="flex items-center justify-between px-4 sm:px-6 lg:px-8 h-16">
                <div class="flex items-center gap-4">
                    <button class="lg:hidden text-slate-500 hover:text-slate-700" onclick="toggleSidebar()">
                        <i class="bi bi-list text-2xl"></i>
                    </button>
                    <?php if (isset($page_title)): ?>
                    <h1 class="text-xl font-bold text-slate-800 truncate"><?php echo htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8'); ?></h1>
                    <?php endif; ?>
                </div>
                <div class="flex items-center gap-4">
                    <div class="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-full border border-slate-200">
                        <i class="bi bi-person-circle text-slate-500"></i>
                        <span class="text-sm font-medium text-slate-700">
                            <?php echo sanitize(current_user()['username'] ?? 'User'); ?>
                        </span>
                    </div>
                    <?php if (isset($page_actions)): ?>
                    <div class="flex items-center gap-2">
                        <?php echo $page_actions; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </header>

        <!-- Flash Messages & Page Content -->
        <div class="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
            <?php
            $flash = get_flash();
            if ($flash): 
                $alertClass = match($flash['type']) {
                    'success' => 'bg-emerald-50 text-emerald-800 border-emerald-200',
                    'danger' => 'bg-red-50 text-red-800 border-red-200',
                    'warning' => 'bg-amber-50 text-amber-800 border-amber-200',
                    'info' => 'bg-blue-50 text-blue-800 border-blue-200',
                    default => 'bg-slate-50 text-slate-800 border-slate-200'
                };
            ?>
            <div class="mb-6 p-4 rounded-lg border flex justify-between items-start <?php echo $alertClass; ?>" role="alert" id="flash-alert">
                <div class="text-sm font-medium"><?php echo htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
                <button type="button" class="text-current opacity-70 hover:opacity-100" onclick="document.getElementById('flash-alert').remove()">
                    <i class="bi bi-x-lg"></i>
                </button>
            </div>
            <?php endif; ?>
