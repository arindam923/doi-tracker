<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

$id = intval($_GET['id'] ?? 0);
if (!$id) redirect(BASE_URL . '/projects/list.php');

$stmt = $pdo->prepare("SELECT p.*, c.client_name FROM projects p LEFT JOIN clients c ON p.client_id = c.id WHERE p.id = ?");
$stmt->execute([$id]);
$project = $stmt->fetch();
if (!$project) {
    set_flash('danger', 'Project not found.');
    redirect(BASE_URL . '/projects/list.php');
}

$clients_list = $pdo->query("SELECT id, client_name, client_code FROM clients WHERE is_active = 1 ORDER BY client_name")->fetchAll();

// ─── Handle POST ───
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect(BASE_URL . '/projects/edit.php?id=' . $id);
    }

    $project_name = trim($_POST['project_name'] ?? '');
    $client_id = intval($_POST['client_id'] ?? 0);
    $client_survey_link = trim($_POST['client_survey_link'] ?? '');
    $client_cpi = floatval($_POST['client_cpi'] ?? 0);
    $vendor_default_cpi = floatval($_POST['vendor_default_cpi'] ?? 0);
    $total_quota = intval($_POST['total_quota'] ?? 0);
    $country_target = trim($_POST['country_target'] ?? '');
    $start_date = trim($_POST['start_date'] ?? '');
    $end_date = trim($_POST['end_date'] ?? '');
    $description = trim($_POST['description'] ?? '');

    $errors = [];
    if (empty($project_name)) $errors[] = 'Project name is required.';
    if (!$client_id) $errors[] = 'Please select a client.';

    if (!empty($errors)) {
        set_flash('danger', implode(' | ', $errors));
        $_SESSION['edit_form_data'] = $_POST;
        redirect(BASE_URL . '/projects/edit.php?id=' . $id);
    }

    $stmt = $pdo->prepare("
        UPDATE projects SET project_name=?, client_id=?, client_survey_link=?, client_cpi=?, vendor_default_cpi=?,
            total_quota=?, country_target=?, start_date=?, end_date=?, description=?
        WHERE id=?
    ");
    $stmt->execute([
        $project_name, $client_id, $client_survey_link, $client_cpi, $vendor_default_cpi,
        $total_quota, $country_target, $start_date ?: null, $end_date ?: null, $description, $id
    ]);

    regenerate_csrf_token();
    set_flash('success', 'Project updated successfully.');
    redirect(BASE_URL . '/projects/detail.php?id=' . $id);
}

$page_title = 'Edit Project';

// Pre-fill with submitted data if validation failed
$edit_form = $_SESSION['edit_form_data'] ?? null;
unset($_SESSION['edit_form_data']);

require_once __DIR__ . '/../helpers/layout_header.php';
?>

<div class="flex flex-wrap -mx-3 justify-center">
    <div class="col-lg-10">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header">
                <h6 class="mb-0 font-semibold">Edit: <?php echo sanitize($project['project_name']); ?></h6>
                <code><?php echo sanitize($project['project_code']); ?></code>
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <?php $f = $edit_form; // shorthand ?>
                    <div class="flex flex-wrap -mx-3 g-3">
                        <div class="w-full md:w-2/3 px-3">
                            <label for="project_name" class="block text-sm font-medium text-slate-700 mb-1">Project Name <span class="text-red-600">*</span></label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="project_name" name="project_name"
                                   value="<?php echo sanitize($f ? $f['project_name'] : $project['project_name']); ?>" required>
                        </div>
                        <div class="w-full md:w-1/3 px-3">
                            <label for="client_id" class="block text-sm font-medium text-slate-700 mb-1">Client <span class="text-red-600">*</span></label>
                            <select class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white" id="client_id" name="client_id" required>
                                <?php foreach ($clients_list as $c): ?>
                                <option value="<?php echo $c['id']; ?>" <?php echo ($f ? $f['client_id'] : $project['client_id']) == $c['id'] ? 'selected' : ''; ?>>
                                    <?php echo sanitize($c['client_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="w-full px-3">
                            <label for="client_survey_link" class="block text-sm font-medium text-slate-700 mb-1">Client Survey Link</label>
                            <input type="url" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="client_survey_link" name="client_survey_link"
                                   value="<?php echo sanitize($f ? $f['client_survey_link'] : ($project['client_survey_link'] ?? '')); ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="client_cpi" class="block text-sm font-medium text-slate-700 mb-1">Client CPI</label>
                            <div class="flex rounded-md shadow-sm">
                                <span class="flex rounded-md shadow-sm-text">$</span>
                                <input type="number" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="client_cpi" name="client_cpi"
                                       value="<?php echo sanitize($f ? $f['client_cpi'] : $project['client_cpi']); ?>" step="0.01" min="0">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label for="vendor_default_cpi" class="block text-sm font-medium text-slate-700 mb-1">Default Vendor Payout per Conversion</label>
                            <div class="flex rounded-md shadow-sm">
                                <span class="flex rounded-md shadow-sm-text">$</span>
                                <input type="number" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="vendor_default_cpi" name="vendor_default_cpi"
                                       value="<?php echo sanitize($f ? $f['vendor_default_cpi'] : $project['vendor_default_cpi']); ?>" step="0.01" min="0">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label for="total_quota" class="block text-sm font-medium text-slate-700 mb-1">Total Quota</label>
                            <input type="number" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="total_quota" name="total_quota"
                                   value="<?php echo sanitize($f ? $f['total_quota'] : $project['total_quota']); ?>" min="0">
                        </div>
                        <div class="col-md-3">
                            <label for="country_target" class="block text-sm font-medium text-slate-700 mb-1">Target Country</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="country_target" name="country_target"
                                   value="<?php echo sanitize($f ? $f['country_target'] : ($project['country_target'] ?? '')); ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="start_date" class="block text-sm font-medium text-slate-700 mb-1">Start Date</label>
                            <input type="date" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="start_date" name="start_date"
                                   value="<?php echo sanitize($f ? $f['start_date'] : ($project['start_date'] ?? '')); ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="end_date" class="block text-sm font-medium text-slate-700 mb-1">End Date</label>
                            <input type="date" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="end_date" name="end_date"
                                   value="<?php echo sanitize($f ? $f['end_date'] : ($project['end_date'] ?? '')); ?>">
                        </div>
                        <div class="w-full px-3">
                            <label for="description" class="block text-sm font-medium text-slate-700 mb-1">Description</label>
                            <textarea class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="description" name="description" rows="3"><?php echo sanitize($f ? $f['description'] : ($project['description'] ?? '')); ?></textarea>
                        </div>
                    </div>
                    <div class="mt-6 flex gap-2">
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors"><i class="bi bi-check-lg me-1"></i>Save Changes</button>
                        <a href="<?php echo BASE_URL; ?>/projects/detail.php?id=<?php echo $id; ?>" class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
