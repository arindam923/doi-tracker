<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

// ─── Filters ───
$search = trim($_GET['search'] ?? ''); // Don't sanitize for SQL — use trim only; escape at output
$status_filter = $_GET['status'] ?? '';
$client_filter = intval($_GET['client_id'] ?? 0);
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 50;

$where = [];
$params = [];

if ($search) {
    $where[] = "(p.project_code LIKE ? OR p.project_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($status_filter && in_array($status_filter, ['live','hold','closed'])) {
    $where[] = "p.status = ?";
    $params[] = $status_filter;
}
if ($client_filter) {
    $where[] = "p.client_id = ?";
    $params[] = $client_filter;
}

$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$count_stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM projects p $where_sql");
$count_stmt->execute($params);
$total = $count_stmt->fetch()['cnt'];

$pagination = paginate($total, $per_page, $page);

$stmt = $pdo->prepare("
    SELECT p.*, c.client_name
    FROM projects p
    LEFT JOIN clients c ON p.client_id = c.id
    $where_sql
    ORDER BY p.updated_at DESC
    LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}
");
$stmt->execute($params);
$projects = $stmt->fetchAll();

// Fetch clients for filter dropdown
$clients_list = $pdo->query("SELECT id, client_name FROM clients WHERE is_active = 1 ORDER BY client_name")->fetchAll();

$page_title = 'Projects';
$page_actions = '<a href="' . BASE_URL . '/projects/create.php" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors btn-sm"><i class="bi bi-plus-lg me-1"></i>New Project</a>';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<!-- Filters -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6 py-2">
        <form method="GET" class="flex flex-wrap -mx-3 g-2 align-items-end">
            <div class="col-md-3">
                <input type="text" name="search" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm" placeholder="Search projects..."
                       value="<?php echo $search; ?>">
            </div>
            <div class="col-md-2">
                <select name="status" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white-sm">
                    <option value="">All Status</option>
                    <option value="live" <?php echo $status_filter === 'live' ? 'selected' : ''; ?>>Live</option>
                    <option value="hold" <?php echo $status_filter === 'hold' ? 'selected' : ''; ?>>Hold</option>
                    <option value="closed" <?php echo $status_filter === 'closed' ? 'selected' : ''; ?>>Closed</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="client_id" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white-sm">
                    <option value="">All Clients</option>
                    <?php foreach ($clients_list as $cl): ?>
                    <option value="<?php echo $cl['id']; ?>" <?php echo $client_filter == $cl['id'] ? 'selected' : ''; ?>>
                        <?php echo sanitize($cl['client_name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-1 px-3 rounded-lg text-sm transition-colors w-100">Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Projects Table -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="overflow-x-auto w-full">
        <table class="min-w-full text-left border-collapse mb-0">
            <thead>
                <tr>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Code</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Project Name</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Client</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Status</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Quota</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Clicks</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Completes</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">CCR</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($projects)): ?>
                <tr>
                    <td colspan="9" class="text-center text-slate-500 py-4">
                        <div class="text-center py-12 text-slate-500">
                            <i class="bi bi-folder2-open d-block"></i>
                            <h5>No projects found</h5>
                            <p>Create your first project to start tracking.</p>
                        </div>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($projects as $p): ?>
                <?php $ccr = calc_ccr($p['completes_count'], $p['clicks_count']); ?>
                <tr>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><code class="small"><?php echo sanitize($p['project_code']); ?></code></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100">
                        <a href="<?php echo BASE_URL; ?>/projects/detail.php?id=<?php echo $p['id']; ?>" class="font-semibold text-decoration-none">
                            <?php echo sanitize($p['project_name']); ?>
                        </a>
                    </td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo sanitize($p['client_name'] ?? '-'); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo status_badge($p['status']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100">
                        <?php if ($p['total_quota'] > 0): ?>
                        <div class="flex items-center gap-2">
                            <div class="tf-progress" style="width: 60px;">
                                <div class="tf-progress-bar bg-<?php echo $p['completes_count'] >= $p['total_quota'] ? 'danger' : ($p['completes_count'] >= $p['total_quota'] * 0.8 ? 'warning' : 'success'); ?>"
                                     style="width: <?php echo min(100, ($p['completes_count'] / $p['total_quota']) * 100); ?>%"></div>
                            </div>
                            <small><?php echo $p['completes_count']; ?>/<?php echo $p['total_quota']; ?></small>
                        </div>
                        <?php else: ?>
                        <span class="text-slate-500">No limit</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo number_format($p['clicks_count']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo number_format($p['completes_count']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><span class="badge bg-<?php echo ccr_color($ccr); ?>"><?php echo $ccr; ?>%</span></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100">
                        <div class="actions-dropdown dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                <i class="bi bi-three-dots"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/projects/edit.php?id=<?php echo $p['id']; ?>"><i class="bi bi-pencil me-2"></i>Edit</a></li>
                                <li>
                                    <form method="POST" action="<?php echo BASE_URL; ?>/projects/clone.php" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
                                        <button type="submit" class="dropdown-item" data-confirm="Clone this project?"><i class="bi bi-copy me-2"></i>Clone</button>
                                    </form>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#statusModal<?php echo $p['id']; ?>"><i class="bi bi-toggle2-left me-2"></i>Change Status</a></li>
                                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#linksModal<?php echo $p['id']; ?>"><i class="bi bi-link-45deg me-2"></i>View Links</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/vendors/list.php?project_id=<?php echo $p['id']; ?>"><i class="bi bi-people me-2"></i>Vendors</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/reports/overview.php?project_id=<?php echo $p['id']; ?>"><i class="bi bi-graph-up me-2"></i>Report</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form method="POST" action="<?php echo BASE_URL; ?>/projects/delete.php" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
                                        <button type="submit" class="dropdown-item text-red-600" data-confirm="Delete this project? This cannot be undone."><i class="bi bi-trash me-2"></i>Delete</button>
                                    </form>
                                </li>
                            </ul>
                        </div>

                        <!-- Status Modal -->
                        <div class="modal fade" id="statusModal<?php echo $p['id']; ?>" tabindex="-1">
                            <div class="modal-dialog modal-sm">
                                <div class="modal-content">
                                    <form method="POST" action="<?php echo BASE_URL; ?>/projects/status.php">
                                        <input type="hidden" name="project_id" value="<?php echo $p['id']; ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-header">
                                            <h6 class="modal-title">Change Status</h6>
                                            <button type="button" class="text-slate-400 hover:text-slate-600 font-bold" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <select name="new_status" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white">
                                                <option value="live" <?php echo $p['status'] === 'live' ? 'selected' : ''; ?>>🟢 Live</option>
                                                <option value="hold" <?php echo $p['status'] === 'hold' ? 'selected' : ''; ?>>🟡 Hold</option>
                                                <option value="closed" <?php echo $p['status'] === 'closed' ? 'selected' : ''; ?>>🔴 Closed</option>
                                            </select>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors btn-sm">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <!-- Links Modal -->
                        <div class="modal fade" id="linksModal<?php echo $p['id']; ?>" tabindex="-1">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h6 class="modal-title">Project Links</h6>
                                        <button type="button" class="text-slate-400 hover:text-slate-600 font-bold" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-6">
                                            <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold">Client Postback URL</label>
                                            <div class="flex rounded-md shadow-sm">
                                                <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm font-monospace" readonly
                                                       value="<?php echo BASE_URL; ?>/tracking/postback.php?click_id={click_id}&status=1&token=<?php echo sanitize($p['postback_token']); ?>">
                                                <button class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors btn-sm btn-copy" data-copy="<?php echo BASE_URL; ?>/tracking/postback.php?click_id={click_id}&status=1&token=<?php echo sanitize($p['postback_token']); ?>"><i class="bi bi-clipboard"></i></button>
                                            </div>
                                        </div>
                                        <div class="mb-6">
                                            <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold">Postback Token</label>
                                            <div class="flex rounded-md shadow-sm">
                                                <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm font-monospace" readonly
                                                       value="<?php echo sanitize($p['postback_token']); ?>">
                                                <button class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors btn-sm btn-copy" data-copy="<?php echo sanitize($p['postback_token']); ?>"><i class="bi bi-clipboard"></i></button>
                                            </div>
                                        </div>
                                        <?php
                                        $vstmt = $pdo->prepare("SELECT * FROM vendors WHERE project_id = ?");
                                        $vstmt->execute([$p['id']]);
                                        $project_vendors = $vstmt->fetchAll();
                                        if ($project_vendors): ?>
                                        <hr>
                                        <h6 class="font-semibold">Vendor Tracking Links</h6>
                                        <?php foreach ($project_vendors as $v): ?>
                                        <div class="mb-2">
                                            <label class="block text-sm font-medium text-slate-700 mb-1 small"><?php echo sanitize($v['vendor_name']); ?> <?php echo status_badge($v['status']); ?></label>
                                            <div class="flex rounded-md shadow-sm">
                                                <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm font-monospace" readonly
                                                       value="<?php echo BASE_URL; ?>/tracking/click.php?project_id=<?php echo $p['id']; ?>&vendor_id=<?php echo $v['id']; ?>">
                                                <button class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors btn-sm btn-copy" data-copy="<?php echo BASE_URL; ?>/tracking/click.php?project_id=<?php echo $p['id']; ?>&vendor_id=<?php echo $v['id']; ?>"><i class="bi bi-clipboard"></i></button>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
echo render_pagination($pagination, BASE_URL . '/projects/list.php');
require_once __DIR__ . '/../helpers/layout_footer.php';
?>
