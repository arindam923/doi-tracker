<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

$id = intval($_GET['id'] ?? 0);
if (!$id) redirect(BASE_URL . '/projects/list.php');

$stmt = $pdo->prepare("SELECT p.*, c.client_name, c.client_code, c.default_currency FROM projects p LEFT JOIN clients c ON p.client_id = c.id WHERE p.id = ?");
$stmt->execute([$id]);
$project = $stmt->fetch();
if (!$project) {
    set_flash('danger', 'Project not found.');
    redirect(BASE_URL . '/projects/list.php');
}

// Fetch vendors
$vstmt = $pdo->prepare("SELECT * FROM vendors WHERE project_id = ? ORDER BY vendor_name");
$vstmt->execute([$id]);
$vendors = $vstmt->fetchAll();

// Vendor stats — single aggregate query instead of N+1
$vendor_stats = [];
$vs_stmt = $pdo->prepare("
    SELECT v.id,
        COUNT(DISTINCT cl.id) as clicks,
        SUM(cl.is_converted) as converts,
        COUNT(DISTINCT cv.id) as cnt,
        COALESCE(SUM(cv.client_revenue),0) as rev,
        COALESCE(SUM(cv.vendor_cost),0) as cost,
        COALESCE(SUM(cv.profit),0) as profit
    FROM vendors v
    LEFT JOIN clicks cl ON cl.vendor_id = v.id AND cl.project_id = v.project_id
    LEFT JOIN conversions cv ON cv.vendor_id = v.id AND cv.project_id = v.project_id AND cv.status = 'complete'
    WHERE v.project_id = ?
    GROUP BY v.id
");
$vs_stmt->execute([$id]);
while ($row = $vs_stmt->fetch()) {
    $vendor_stats[$row['id']] = [
        'clicks' => $row['clicks'] ?? 0,
        'completes' => $row['cnt'] ?? 0,
        'revenue' => $row['rev'] ?? 0,
        'cost' => $row['cost'] ?? 0,
        'profit' => $row['profit'] ?? 0,
    ];
}

// Chart data: last 7 days — single query
$chart_labels = [];
$chart_clicks = [];
$chart_conversions = [];

$chart_click_data = [];
$chart_conv_data = [];

$cc_stmt = $pdo->prepare("SELECT DATE(clicked_at) as d, COUNT(*) as cnt FROM clicks WHERE project_id = ? AND clicked_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(clicked_at)");
$cc_stmt->execute([$id]);
while ($row = $cc_stmt->fetch()) { $chart_click_data[$row['d']] = $row['cnt']; }

$ccv_stmt = $pdo->prepare("SELECT DATE(converted_at) as d, COUNT(*) as cnt FROM conversions WHERE project_id = ? AND status = 'complete' AND converted_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(converted_at)");
$ccv_stmt->execute([$id]);
while ($row = $ccv_stmt->fetch()) { $chart_conv_data[$row['d']] = $row['cnt']; }

for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $chart_labels[] = date('M d', strtotime($d));
    $chart_clicks[] = $chart_click_data[$d] ?? 0;
    $chart_conversions[] = $chart_conv_data[$d] ?? 0;
}

$ccr = calc_ccr($project['completes_count'], $project['clicks_count']);
$currency = $project['default_currency'] ?? 'USD';

// Use actual SUM from conversions for accuracy (not denormalized counter)
$rev_stmt = $pdo->prepare("SELECT COALESCE(SUM(client_revenue),0) as rev, COALESCE(SUM(vendor_cost),0) as cost, COALESCE(SUM(profit),0) as profit FROM conversions WHERE project_id = ? AND status = 'complete'");
$rev_stmt->execute([$id]);
$rev_data = $rev_stmt->fetch();
$total_revenue = $rev_data['rev'];
$total_cost = $rev_data['cost'];
$total_profit = $rev_data['profit'];

$page_title = $project['project_name'];

// Page actions
$csrf_field_html = '<input type="hidden" name="csrf_token" value="' . generate_csrf_token() . '">';
$page_actions = '
<div class="flex gap-2">
    <a href="' . BASE_URL . '/tracking/manual.php?project_id=' . $id . '" class="btn btn-sm btn-warning"><i class="bi bi-plus-circle me-1"></i>Manual Conversion</a>
    <a href="' . BASE_URL . '/projects/edit.php?id=' . $id . '" class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-1 px-3 rounded-lg text-sm transition-colors"><i class="bi bi-pencil me-1"></i>Edit</a>
    <form method="POST" action="' . BASE_URL . '/projects/clone.php" class="d-inline">
        ' . $csrf_field_html . '
        <input type="hidden" name="id" value="' . $id . '">
        <button type="submit" class="btn btn-sm btn-outline-secondary" data-confirm="Clone this project?"><i class="bi bi-copy me-1"></i>Clone</button>
    </form>
</div>';

require_once __DIR__ . '/../helpers/layout_header.php';
?>

<!-- Project Info Cards -->
<div class="flex flex-wrap -mx-3 g-3 mb-6">
    <div class="col-md-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">Status</div>
            <div><?php echo status_badge($project['status']); ?></div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">Clicks</div>
            <div class="tf-stat-value"><?php echo number_format($project['clicks_count']); ?></div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">Completes</div>
            <div class="tf-stat-value"><?php echo number_format($project['completes_count']); ?></div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">CCR</div>
            <div class="tf-stat-value"><span class="badge bg-<?php echo ccr_color($ccr); ?> fs-6"><?php echo $ccr; ?>%</span></div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">Revenue</div>
            <div class="tf-stat-value text-emerald-600"><?php echo format_currency($total_revenue, $currency); ?></div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="tf-stat-bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="tf-stat-label">Profit</div>
            <div class="tf-stat-value text-<?php echo $total_profit >= 0 ? 'success' : 'danger'; ?>"><?php echo format_currency($total_profit, $currency); ?></div>
        </div>
    </div>
</div>

<!-- Quota Progress -->
<?php if ($project['total_quota'] > 0): ?>
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div class="flex justify-between mb-2">
            <span class="font-semibold">Quota Progress</span>
            <span><?php echo $project['completes_count']; ?> / <?php echo number_format($project['total_quota']); ?> completes</span>
        </div>
        <div class="tf-progress" style="height: 20px; border-radius: 10px;">
            <?php $pct = min(100, ($project['completes_count'] / $project['total_quota']) * 100); ?>
            <div class="tf-progress-bar bg-<?php echo $pct >= 100 ? 'danger' : ($pct >= 80 ? 'warning' : 'success'); ?>"
                 style="width: <?php echo $pct; ?>%; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 0.75rem; font-weight: 600;">
                <?php echo round($pct); ?>%
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Project Details -->
<div class="flex flex-wrap -mx-3 g-3 mb-6">
    <div class="w-full md:w-1/2 px-3">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden h-100">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header"><h6 class="mb-0 font-semibold">Project Info</h6></div>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <table class="min-w-full text-left border-collapse min-w-full text-left border-collapse-sm min-w-full text-left border-collapse-borderless mb-0">
                    <tr><td class="text-slate-500" style="width:140px">Code</td><td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><code><?php echo sanitize($project['project_code']); ?></code></td></tr>
                    <tr><td class="text-slate-500">Client</td><td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo sanitize($project['client_name'] ?? '-'); ?></td></tr>
                    <tr><td class="text-slate-500">Country</td><td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo sanitize($project['country_target'] ?? '-'); ?></td></tr>
                    <tr><td class="text-slate-500">Client CPI</td><td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo format_currency($project['client_cpi'], $currency); ?></td></tr>
                    <tr><td class="text-slate-500">Default Vendor Payout</td><td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo format_currency($project['vendor_default_cpi'], $currency); ?></td></tr>
                    <tr><td class="text-slate-500">Start Date</td><td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo $project['start_date'] ?: '-'; ?></td></tr>
                    <tr><td class="text-slate-500">End Date</td><td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo $project['end_date'] ?: '-'; ?></td></tr>
                </table>
            </div>
        </div>
    </div>
    <div class="w-full md:w-1/2 px-3">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden h-100">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header"><h6 class="mb-0 font-semibold">Links & Tokens</h6></div>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div class="mb-6">
                    <label class="block text-sm font-medium text-slate-700 mb-1 small text-slate-500">Client Postback URL</label>
                    <div class="flex rounded-md shadow-sm flex rounded-md shadow-sm-sm">
                        <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm font-monospace" readonly
                               value="<?php echo BASE_URL; ?>/tracking/postback.php?click_id={click_id}&status=1&token=<?php echo sanitize($project['postback_token']); ?>">
                        <button class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors btn-sm btn-copy" data-copy="<?php echo BASE_URL; ?>/tracking/postback.php?click_id={click_id}&status=1&token=<?php echo sanitize($project['postback_token']); ?>"><i class="bi bi-clipboard"></i></button>
                    </div>
                </div>
                <div class="mb-6">
                    <label class="block text-sm font-medium text-slate-700 mb-1 small text-slate-500">Postback Token</label>
                    <div class="flex rounded-md shadow-sm flex rounded-md shadow-sm-sm">
                        <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm font-monospace" readonly
                               value="<?php echo sanitize($project['postback_token']); ?>">
                        <button class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors btn-sm btn-copy" data-copy="<?php echo sanitize($project['postback_token']); ?>"><i class="bi bi-clipboard"></i></button>
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1 small text-slate-500">Survey Link</label>
                    <div class="flex rounded-md shadow-sm flex rounded-md shadow-sm-sm">
                        <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm font-monospace" readonly
                               value="<?php echo sanitize($project['client_survey_link'] ?? ''); ?>">
                        <button class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors btn-sm btn-copy" data-copy="<?php echo sanitize($project['client_survey_link'] ?? ''); ?>"><i class="bi bi-clipboard"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header"><h6 class="mb-0 font-semibold">Clicks & Conversions — Last 7 Days</h6></div>
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6"><div style="height: 250px;"><canvas id="projectChart"></canvas></div></div>
</div>

<!-- Vendors Table -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header">
        <h6 class="mb-0 font-semibold">Vendors</h6>
        <?php if ($project['status'] === 'live'): ?>
        <a href="<?php echo BASE_URL; ?>/vendors/create.php?project_id=<?php echo $id; ?>" class="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-1 px-3 rounded-lg text-sm shadow-sm transition-colors"><i class="bi bi-plus-lg me-1"></i>Add Vendor</a>
        <?php endif; ?>
    </div>
    <div class="overflow-x-auto w-full">
        <table class="min-w-full text-left border-collapse mb-0">
            <thead>
                <tr>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Vendor</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">CPI</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Tracking Link</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Clicks</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Completes</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">CCR</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Revenue</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Cost</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Profit</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Status</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($vendors)): ?>
                <tr><td colspan="11" class="text-center text-slate-500 py-3">No vendors added yet.</td></tr>
                <?php else: ?>
                <?php foreach ($vendors as $v): ?>
                <?php $vs = $vendor_stats[$v['id']]; $vccr = calc_ccr($vs['completes'], $vs['clicks']); ?>
                <tr>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><strong><?php echo sanitize($v['vendor_name']); ?></strong></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo format_currency($v['vendor_cpi'], $currency); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100">
                        <div class="flex rounded-md shadow-sm flex rounded-md shadow-sm-sm" style="max-width: 250px;">
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm font-monospace" readonly
                                   value=".../click.php?project_id=<?php echo $id; ?>&vendor_id=<?php echo $v['id']; ?>">
                            <button class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors btn-sm btn-copy" data-copy="<?php echo BASE_URL; ?>/tracking/click.php?project_id=<?php echo $id; ?>&vendor_id=<?php echo $v['id']; ?>"><i class="bi bi-clipboard"></i></button>
                        </div>
                    </td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo number_format($vs['clicks']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo number_format($vs['completes']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><span class="badge bg-<?php echo ccr_color($vccr); ?>"><?php echo $vccr; ?>%</span></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo format_currency($vs['revenue'], $currency); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo format_currency($vs['cost'], $currency); ?></td>
                    <td class="text-<?php echo $vs['profit'] >= 0 ? 'success' : 'danger'; ?>"><?php echo format_currency($vs['profit'], $currency); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo status_badge($v['status']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100">
                        <a href="<?php echo BASE_URL; ?>/vendors/edit.php?id=<?php echo $v['id']; ?>" class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-1 px-3 rounded-lg text-sm transition-colors" title="Edit"><i class="bi bi-pencil"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Description -->
<?php if ($project['description']): ?>
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header"><h6 class="mb-0 font-semibold">Description</h6></div>
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6"><p class="mb-0"><?php echo nl2br(sanitize($project['description'])); ?></p></div>
</div>
<?php endif; ?>

<?php
$cl_json = json_encode($chart_labels);
$cc_json = json_encode($chart_clicks);
$cvt_json = json_encode($chart_conversions);

$extra_js = <<<EOT
<script>
new Chart(document.getElementById('projectChart'), {
    type: 'bar',
    data: {
        labels: {$cl_json},
        datasets: [
            { label: 'Clicks', data: {$cc_json}, backgroundColor: 'rgba(79,70,229,0.7)', borderRadius: 4 },
            { label: 'Conversions', data: {$cvt_json}, backgroundColor: 'rgba(16,185,129,0.7)', borderRadius: 4 }
        ]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }
});
</script>
EOT;

require_once __DIR__ . '/../helpers/layout_footer.php';
?>
