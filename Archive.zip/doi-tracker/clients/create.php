<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

// ─── Handle POST ───
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect(BASE_URL . '/clients/create.php');
    }

    $client_name = trim($_POST['client_name'] ?? '');
    $client_code = strtoupper(trim($_POST['client_code'] ?? ''));
    $contact_person = trim($_POST['contact_person'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $default_currency = trim($_POST['default_currency'] ?? 'USD');
    $notes = trim($_POST['notes'] ?? '');

    // Validate
    $errors = [];
    if (empty($client_name)) $errors[] = 'Client name is required.';
    if (empty($client_code)) $errors[] = 'Client code is required.';
    if (strlen($client_code) < 2 || strlen($client_code) > 20) $errors[] = 'Client code must be 2-20 characters.';

    // Check uniqueness
    if (empty($errors)) {
        $check = $pdo->prepare("SELECT id FROM clients WHERE client_code = ?");
        $check->execute([$client_code]);
        if ($check->fetch()) $errors[] = 'Client code already exists. Please choose a different one.';
    }

    if (!empty($errors)) {
        set_flash('danger', implode(' | ', $errors));
        $_SESSION['form_data'] = $_POST;
        redirect(BASE_URL . '/clients/create.php');
    }

    // Insert
    $stmt = $pdo->prepare("INSERT INTO clients (client_name, client_code, contact_person, email, phone, country, default_currency, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$client_name, $client_code, $contact_person, $email, $phone, $country, $default_currency, $notes]);

    regenerate_csrf_token();
    set_flash('success', 'Client "' . $client_name . '" created successfully.');
    redirect(BASE_URL . '/clients/list.php');
}

$form_data = $_SESSION['form_data'] ?? [];
unset($_SESSION['form_data']);

$page_title = 'Add New Client';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<div class="flex flex-wrap -mx-3 justify-center">
    <div class="col-lg-8 max-w-3xl mx-auto">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header">
                <h6 class="mb-0 font-semibold">Client Details</h6>
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <form method="POST" id="clientForm">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-wrap -mx-3 g-3">
                        <div class="w-full md:w-2/3 px-3">
                            <label for="client_name" class="block text-sm font-medium text-slate-700 mb-1">Client Name <span class="text-red-600">*</span></label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="client_name" name="client_name"
                                   value="<?php echo sanitize($form_data['client_name'] ?? ''); ?>" required>
                        </div>
                        <div class="w-full md:w-1/3 px-3">
                            <label for="client_code" class="block text-sm font-medium text-slate-700 mb-1">Client Code <span class="text-red-600">*</span></label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="client_code" name="client_code"
                                   value="<?php echo sanitize($form_data['client_code'] ?? ''); ?>"
                                   maxlength="20" style="text-transform: uppercase;" required>
                            <small class="text-slate-500">Short code (e.g. EASD, QCVA)</small>
                        </div>
                        <div class="w-full md:w-1/2 px-3">
                            <label for="contact_person" class="block text-sm font-medium text-slate-700 mb-1">Contact Person</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="contact_person" name="contact_person"
                                   value="<?php echo sanitize($form_data['contact_person'] ?? ''); ?>">
                        </div>
                        <div class="w-full md:w-1/2 px-3">
                            <label for="email" class="block text-sm font-medium text-slate-700 mb-1">Email</label>
                            <input type="email" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="email" name="email"
                                   value="<?php echo sanitize($form_data['email'] ?? ''); ?>">
                        </div>
                        <div class="w-full md:w-1/3 px-3">
                            <label for="phone" class="block text-sm font-medium text-slate-700 mb-1">Phone</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="phone" name="phone"
                                   value="<?php echo sanitize($form_data['phone'] ?? ''); ?>">
                        </div>
                        <div class="w-full md:w-1/3 px-3">
                            <label for="country" class="block text-sm font-medium text-slate-700 mb-1">Country</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="country" name="country"
                                   value="<?php echo sanitize($form_data['country'] ?? ''); ?>">
                        </div>
                        <div class="w-full md:w-1/3 px-3">
                            <label for="default_currency" class="block text-sm font-medium text-slate-700 mb-1">Default Currency</label>
                            <select class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white" id="default_currency" name="default_currency">
                                <?php foreach (['USD','EUR','GBP','INR','AED','SAR','CAD','AUD'] as $cur): ?>
                                <option value="<?php echo $cur; ?>" <?php echo ($form_data['default_currency'] ?? 'USD') === $cur ? 'selected' : ''; ?>><?php echo $cur; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="w-full px-3">
                            <label for="notes" class="block text-sm font-medium text-slate-700 mb-1">Notes</label>
                            <textarea class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="notes" name="notes" rows="3"><?php echo sanitize($form_data['notes'] ?? ''); ?></textarea>
                        </div>
                    </div>
                    <div class="mt-6 flex gap-2">
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors"><i class="bi bi-check-lg me-1"></i>Create Client</button>
                        <a href="<?php echo BASE_URL; ?>/clients/list.php" class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
