<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

// ─── Filters ───
$search = trim($_GET['search'] ?? ''); // Don't sanitize for SQL — use trim only; escape at output
$status_filter = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 50;

// ─── Build Query ───
$where = [];
$params = [];

if ($search) {
    $where[] = "(client_name LIKE ? OR client_code LIKE ? OR contact_person LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($status_filter === 'active') {
    $where[] = "is_active = 1";
} elseif ($status_filter === 'archived') {
    $where[] = "is_active = 0";
}

$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Count
$count_stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM clients $where_sql");
$count_stmt->execute($params);
$total = $count_stmt->fetch()['cnt'];

$pagination = paginate($total, $per_page, $page);

// Fetch
$stmt = $pdo->prepare("SELECT * FROM clients $where_sql ORDER BY created_at DESC LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}");
$stmt->execute($params);
$clients = $stmt->fetchAll();

// Count projects per client
$client_ids = array_column($clients, 'id');
$project_counts = [];
if (!empty($client_ids)) {
    $placeholders = implode(',', array_fill(0, count($client_ids), '?'));
    $pstmt = $pdo->prepare("SELECT client_id, COUNT(*) as cnt FROM projects WHERE client_id IN ($placeholders) GROUP BY client_id");
    $pstmt->execute($client_ids);
    while ($row = $pstmt->fetch()) {
        $project_counts[$row['client_id']] = $row['cnt'];
    }
}

$page_title = 'Clients';
$page_actions = '<a href="' . BASE_URL . '/clients/create.php" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors btn-sm"><i class="bi bi-plus-lg me-1"></i>Add Client</a>';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<!-- Filters -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6 py-2">
        <form method="GET" class="flex flex-wrap -mx-3 g-2 align-items-end">
            <div class="w-full md:w-1/3 px-3">
                <input type="text" name="search" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm" placeholder="Search clients..."
                       value="<?php echo $search; ?>">
            </div>
            <div class="col-md-3">
                <select name="status" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white-sm">
                    <option value="">All Status</option>
                    <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="archived" <?php echo $status_filter === 'archived' ? 'selected' : ''; ?>>Archived</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-1 px-3 rounded-lg text-sm transition-colors w-100">Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Clients Table -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="overflow-x-auto w-full">
        <table class="min-w-full text-left border-collapse mb-0">
            <thead>
                <tr>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Client Name</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Code</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Contact</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Email</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Country</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Projects</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Status</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($clients)): ?>
                <tr>
                    <td colspan="8" class="text-center text-slate-500 py-4">
                        <div class="text-center py-12 text-slate-500">
                            <i class="bi bi-building d-block"></i>
                            <h5>No clients found</h5>
                            <p>Add your first client to get started.</p>
                        </div>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($clients as $c): ?>
                <tr>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><strong><?php echo sanitize($c['client_name']); ?></strong></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><code><?php echo sanitize($c['client_code']); ?></code></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo sanitize($c['contact_person'] ?? '-'); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo sanitize($c['email'] ?? '-'); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo sanitize($c['country'] ?? '-'); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800"><?php echo $project_counts[$c['id']] ?? 0; ?></span></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo $c['is_active'] ? '<span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">Active</span>' : '<span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800">Archived</span>'; ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100">
                        <div class="actions-dropdown dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                Actions
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/clients/edit.php?id=<?php echo $c['id']; ?>"><i class="bi bi-pencil me-2"></i>Edit</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/projects/list.php?client_id=<?php echo $c['id']; ?>"><i class="bi bi-folder2 me-2"></i>View Projects</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <?php if ($c['is_active']): ?>
                                <li>
                                    <form method="POST" action="<?php echo BASE_URL; ?>/clients/archive.php" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo $c['id']; ?>">
                                        <input type="hidden" name="action" value="archive">
                                        <button type="submit" class="dropdown-item text-amber-500" data-confirm="Archive this client? Projects will not be affected."><i class="bi bi-archive me-2"></i>Archive</button>
                                    </form>
                                </li>
                                <?php else: ?>
                                <li>
                                    <form method="POST" action="<?php echo BASE_URL; ?>/clients/archive.php" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo $c['id']; ?>">
                                        <input type="hidden" name="action" value="restore">
                                        <button type="submit" class="dropdown-item text-emerald-600"><i class="bi bi-arrow-counterclockwise me-2"></i>Restore</button>
                                    </form>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
echo render_pagination($pagination, BASE_URL . '/clients/list.php');
require_once __DIR__ . '/../helpers/layout_footer.php';
?>
