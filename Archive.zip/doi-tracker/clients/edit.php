<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

$id = intval($_GET['id'] ?? 0);
if (!$id) redirect(BASE_URL . '/clients/list.php');

// Fetch client
$stmt = $pdo->prepare("SELECT * FROM clients WHERE id = ?");
$stmt->execute([$id]);
$client = $stmt->fetch();
if (!$client) {
    set_flash('danger', 'Client not found.');
    redirect(BASE_URL . '/clients/list.php');
}

// ─── Handle POST ───
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect(BASE_URL . '/clients/edit.php?id=' . $id);
    }

    $client_name = trim($_POST['client_name'] ?? '');
    $contact_person = trim($_POST['contact_person'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $default_currency = trim($_POST['default_currency'] ?? 'USD');
    $notes = trim($_POST['notes'] ?? '');

    $errors = [];
    if (empty($client_name)) $errors[] = 'Client name is required.';

    if (!empty($errors)) {
        set_flash('danger', implode(' | ', $errors));
        $_SESSION['edit_form_data'] = $_POST;
        redirect(BASE_URL . '/clients/edit.php?id=' . $id);
    }

    $stmt = $pdo->prepare("UPDATE clients SET client_name=?, contact_person=?, email=?, phone=?, country=?, default_currency=?, notes=? WHERE id=?");
    $stmt->execute([$client_name, $contact_person, $email, $phone, $country, $default_currency, $notes, $id]);

    regenerate_csrf_token();
    set_flash('success', 'Client updated successfully.');
    redirect(BASE_URL . '/clients/list.php');
}

$page_title = 'Edit Client';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<div class="flex flex-wrap -mx-3 justify-center">
    <div class="col-lg-8 max-w-3xl mx-auto">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header">
                <h6 class="mb-0 font-semibold">Edit: <?php echo sanitize($client['client_name']); ?></h6>
                <code><?php echo sanitize($client['client_code']); ?></code>
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-wrap -mx-3 g-3">
                        <div class="w-full md:w-2/3 px-3">
                            <label for="client_name" class="block text-sm font-medium text-slate-700 mb-1">Client Name <span class="text-red-600">*</span></label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="client_name" name="client_name"
                                   value="<?php echo sanitize($client['client_name']); ?>" required>
                        </div>
                        <div class="w-full md:w-1/3 px-3">
                            <label class="block text-sm font-medium text-slate-700 mb-1">Client Code</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" value="<?php echo sanitize($client['client_code']); ?>" disabled>
                            <small class="text-slate-500">Cannot be changed</small>
                        </div>
                        <div class="w-full md:w-1/2 px-3">
                            <label for="contact_person" class="block text-sm font-medium text-slate-700 mb-1">Contact Person</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="contact_person" name="contact_person"
                                   value="<?php echo sanitize($client['contact_person'] ?? ''); ?>">
                        </div>
                        <div class="w-full md:w-1/2 px-3">
                            <label for="email" class="block text-sm font-medium text-slate-700 mb-1">Email</label>
                            <input type="email" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="email" name="email"
                                   value="<?php echo sanitize($client['email'] ?? ''); ?>">
                        </div>
                        <div class="w-full md:w-1/3 px-3">
                            <label for="phone" class="block text-sm font-medium text-slate-700 mb-1">Phone</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="phone" name="phone"
                                   value="<?php echo sanitize($client['phone'] ?? ''); ?>">
                        </div>
                        <div class="w-full md:w-1/3 px-3">
                            <label for="country" class="block text-sm font-medium text-slate-700 mb-1">Country</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="country" name="country"
                                   value="<?php echo sanitize($client['country'] ?? ''); ?>">
                        </div>
                        <div class="w-full md:w-1/3 px-3">
                            <label for="default_currency" class="block text-sm font-medium text-slate-700 mb-1">Default Currency</label>
                            <select class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white" id="default_currency" name="default_currency">
                                <?php foreach (['USD','EUR','GBP','INR','AED','SAR','CAD','AUD'] as $cur): ?>
                                <option value="<?php echo $cur; ?>" <?php echo ($client['default_currency'] ?? 'USD') === $cur ? 'selected' : ''; ?>><?php echo $cur; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="w-full px-3">
                            <label for="notes" class="block text-sm font-medium text-slate-700 mb-1">Notes</label>
                            <textarea class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="notes" name="notes" rows="3"><?php echo sanitize($client['notes'] ?? ''); ?></textarea>
                        </div>
                    </div>
                    <div class="mt-6 flex gap-2">
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors"><i class="bi bi-check-lg me-1"></i>Save Changes</button>
                        <a href="<?php echo BASE_URL; ?>/clients/list.php" class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
