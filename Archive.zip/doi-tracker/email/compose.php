<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

$page_title = 'Send Email';

// Fetch clients with email addresses
$clients = $pdo->query("SELECT id, client_name, email, contact_person FROM clients WHERE is_active = 1 AND email != '' AND email IS NOT NULL ORDER BY client_name")->fetchAll();

require_once __DIR__ . '/../helpers/layout_header.php';
?>

<div class="flex flex-wrap -mx-3 g-4">
    <div class="col-lg-8 max-w-3xl mx-auto">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header">
                <h6 class="mb-0 font-semibold">Compose Email</h6>
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <form method="POST" action="<?php echo BASE_URL; ?>/email/send.php" id="emailForm">
                    <?php echo csrf_field(); ?>
                    <div class="mb-6">
                        <label class="block text-sm font-medium text-slate-700 mb-1">Recipients <span class="text-red-600">*</span></label>
                        <div class="mb-2">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="recipient_mode" id="modeSelected" value="selected" checked onchange="toggleRecipientMode()">
                                <label class="form-check-label" for="modeSelected">Selected clients</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="recipient_mode" id="modeAll" value="all" onchange="toggleRecipientMode()">
                                <label class="form-check-label" for="modeAll">All clients with email</label>
                            </div>
                        </div>
                        <div id="recipientSelector">
                            <select class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white" name="client_ids[]" id="client_ids" multiple size="8">
                                <?php foreach ($clients as $c): ?>
                                <option value="<?php echo $c['id']; ?>">
                                    <?php echo sanitize($c['client_name']); ?>
                                    <?php if ($c['contact_person']): ?>— <?php echo sanitize($c['contact_person']); ?><?php endif; ?>
                                    (<?php echo sanitize($c['email']); ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <small class="text-slate-500"><?php echo count($clients); ?> clients with email addresses</small>
                        </div>
                        <div id="allRecipientNotice" class="p-4 mb-4 text-sm text-cyan-800 rounded-lg bg-cyan-50 d-none mb-0 mt-2 py-2 small">
                            <i class="bi bi-info-circle me-1"></i>
                            Email will be sent to all <?php echo count($clients); ?> clients with email addresses.
                        </div>
                    </div>
                    <div class="mb-6">
                        <label for="subject" class="block text-sm font-medium text-slate-700 mb-1">Subject <span class="text-red-600">*</span></label>
                        <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="subject" name="subject" required maxlength="300" placeholder="Enter email subject">
                    </div>
                    <div class="mb-6">
                        <label for="body" class="block text-sm font-medium text-slate-700 mb-1">Message <span class="text-red-600">*</span></label>
                        <textarea class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="body" name="body" rows="14" required placeholder="Write your email message here..."></textarea>
                        <small class="text-slate-500">Plain text only. Each recipient will receive an individual email.</small>
                    </div>
                    <div class="flex gap-2">
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors" id="sendBtn">
                            <i class="bi bi-send me-1"></i>Send Email
                        </button>
                        <button type="button" class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors" onclick="previewEmail()">
                            <i class="bi bi-eye me-1"></i>Preview
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header">
                <h6 class="mb-0 font-semibold">Recipients Overview</h6>
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div class="tf-stat-label">Total clients with email</div>
                <div class="tf-stat-value"><?php echo count($clients); ?></div>
                <hr>
                <div class="tf-stat-label">Recipients selected</div>
                <div class="tf-stat-value" id="selectedCount">0</div>
                <hr>
                <a href="<?php echo BASE_URL; ?>/email/history.php" class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-1 px-3 rounded-lg text-sm transition-colors w-100">
                    <i class="bi bi-clock-history me-1"></i>View Sent History
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title">Email Preview</h6>
                <button type="button" class="text-slate-400 hover:text-slate-600 font-bold" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-6">
                    <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold">To:</label>
                    <p class="mb-0" id="previewTo">—</p>
                </div>
                <div class="mb-6">
                    <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold">Subject:</label>
                    <p class="mb-0" id="previewSubject">—</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold">Message:</label>
                    <pre class="bg-light p-3 rounded" id="previewBody" style="white-space: pre-wrap; font-family: inherit; font-size: 0.9rem;">—</pre>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
function toggleRecipientMode() {
    const mode = document.querySelector('input[name="recipient_mode"]:checked').value;
    document.getElementById('recipientSelector').classList.toggle('d-none', mode !== 'selected');
    document.getElementById('allRecipientNotice').classList.toggle('d-none', mode !== 'all');
}

document.getElementById('client_ids').addEventListener('change', function() {
    document.getElementById('selectedCount').textContent = this.selectedOptions.length;
});

document.getElementById('emailForm').addEventListener('submit', function(e) {
    const mode = document.querySelector('input[name="recipient_mode"]:checked').value;
    if (mode === 'selected' && document.getElementById('client_ids').selectedOptions.length === 0) {
        e.preventDefault();
        alert('Please select at least one recipient.');
        return;
    }
    if (!confirm('Send this email to ' + (mode === 'all' ? 'ALL clients' : document.getElementById('client_ids').selectedOptions.length + ' selected client(s)') + '?')) {
        e.preventDefault();
        return;
    }
    document.getElementById('sendBtn').disabled = true;
    document.getElementById('sendBtn').innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Sending...';
});

function previewEmail() {
    const subject = document.getElementById('subject').value || '(no subject)';
    const body = document.getElementById('body').value || '(empty)';
    const mode = document.querySelector('input[name="recipient_mode"]:checked').value;
    const select = document.getElementById('client_ids');
    let recipients;

    if (mode === 'all') {
        recipients = 'All clients with email (<?php echo count($clients); ?> recipients)';
    } else {
        const selected = Array.from(select.selectedOptions).map(o => o.textContent.trim());
        recipients = selected.length ? selected.join('\n') : '(none selected)';
    }

    document.getElementById('previewTo').textContent = recipients;
    document.getElementById('previewSubject').textContent = subject;
    document.getElementById('previewBody').textContent = body;
    new bootstrap.Modal(document.getElementById('previewModal')).show();
}

document.getElementById('selectedCount').textContent = document.getElementById('client_ids').selectedOptions.length;
</script>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
