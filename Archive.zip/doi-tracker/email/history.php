<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

function escape_csv($value) {
    $value = (string)$value;
    if ($value !== '' && in_array($value[0], ['=', '+', '-', '@'])) {
        $value = "'" . $value;
    }
    return $value;
}

$export = isset($_GET['export']) && $_GET['export'] === 'csv';
$page = $export ? 1 : max(1, intval($_GET['page'] ?? 1));
$per_page = $export ? 0 : 50;
$status_filter = $_GET['status'] ?? '';
$date_from = sanitize($_GET['from'] ?? '');
$date_to = sanitize($_GET['to'] ?? '');

$where = [];
$params = [];

if ($status_filter === 'sent') {
    $where[] = "e.status = 'sent'";
} elseif ($status_filter === 'failed') {
    $where[] = "e.status = 'failed'";
}
if ($date_from && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from)) {
    $where[] = "e.created_at >= ?";
    $params[] = $date_from;
}
if ($date_to && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to)) {
    $where[] = "e.created_at <= DATE_ADD(?, INTERVAL 1 DAY)";
    $params[] = $date_to;
}

$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$count_stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM sent_emails e $where_sql");
$count_stmt->execute($params);
$total = $count_stmt->fetch()['cnt'];
$pagination = [];
if (!$export) {
    $pagination = paginate($total, $per_page, $page);
}

$stmt = $pdo->prepare("
    SELECT e.*, u.username as sent_by_name
    FROM sent_emails e
    LEFT JOIN users u ON e.sent_by = u.id
    $where_sql
    ORDER BY e.created_at DESC
    " . ($export ? '' : "LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}")
);
$stmt->execute($params);
$emails = $stmt->fetchAll();

// ─── CSV Export ───
if ($export) {
    $filename = 'email_history_' . date('Y-m-d') . '.csv';

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Time', 'Recipient Email', 'Recipient Name', 'Subject', 'Status', 'Resend ID', 'Error Message', 'Sent By']);

    foreach ($emails as $e) {
        fputcsv($output, [
            escape_csv($e['created_at']),
            escape_csv($e['recipient_email']),
            escape_csv($e['recipient_name']),
            escape_csv($e['subject']),
            escape_csv($e['status']),
            escape_csv($e['resend_id']),
            escape_csv($e['error_message']),
            escape_csv($e['sent_by_name']),
        ]);
    }
    fclose($output);
    exit;
}

$page_title = 'Email History';
$page_actions = '<a href="' . BASE_URL . '/email/compose.php" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors btn-sm"><i class="bi bi-send me-1"></i>Compose Email</a>';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6 py-2">
        <form method="GET" class="flex flex-wrap -mx-3 g-2 align-items-end">
            <div class="col-md-2">
                <select name="status" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white-sm">
                    <option value="">All Status</option>
                    <option value="sent" <?php echo $status_filter === 'sent' ? 'selected' : ''; ?>>Sent</option>
                    <option value="failed" <?php echo $status_filter === 'failed' ? 'selected' : ''; ?>>Failed</option>
                </select>
            </div>
            <div class="col-md-2">
                <input type="date" name="from" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm" value="<?php echo $date_from; ?>" placeholder="From">
            </div>
            <div class="col-md-2">
                <input type="date" name="to" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm" value="<?php echo $date_to; ?>" placeholder="To">
            </div>
            <div class="col-md-2">
                <button type="submit" class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-1 px-3 rounded-lg text-sm transition-colors w-100">Filter</button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo BASE_URL; ?>/email/history.php?export=csv<?php echo $status_filter ? '&status=' . urlencode($status_filter) : ''; ?><?php echo $date_from ? '&from=' . urlencode($date_from) : ''; ?><?php echo $date_to ? '&to=' . urlencode($date_to) : ''; ?>" class="btn btn-sm btn-outline-success w-100"><i class="bi bi-download me-1"></i>Export CSV</a>
            </div>
            <div class="col-md-2">
                <a href="<?php echo BASE_URL; ?>/email/history.php" class="btn btn-sm btn-outline-secondary w-100">Clear</a>
            </div>
        </form>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="overflow-x-auto w-full">
        <table class="min-w-full text-left border-collapse mb-0">
            <thead>
                <tr>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Time</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Recipient</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Subject</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Status</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Sent By</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($emails)): ?>
                <tr>
                    <td colspan="6" class="text-center text-slate-500 py-4">
                        <div class="text-center py-12 text-slate-500">
                            <i class="bi bi-envelope d-block"></i>
                            <h5>No emails sent yet</h5>
                            <p><a href="<?php echo BASE_URL; ?>/email/compose.php">Send your first email</a></p>
                        </div>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($emails as $e): ?>
                <tr>
                    <td class="text-nowrap small"><?php echo time_ago($e['created_at']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100">
                        <strong><?php echo sanitize($e['recipient_name'] ?? $e['recipient_email']); ?></strong>
                        <br><small class="text-slate-500"><?php echo sanitize($e['recipient_email']); ?></small>
                    </td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo sanitize(mb_substr($e['subject'], 0, 60)) . (mb_strlen($e['subject']) > 60 ? '...' : ''); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100">
                        <?php if ($e['status'] === 'sent'): ?>
                        <span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">Sent</span>
                        <?php else: ?>
                        <span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800" title="<?php echo sanitize($e['error_message'] ?? ''); ?>">Failed</span>
                        <?php endif; ?>
                    </td>
                    <td class="small"><?php echo sanitize($e['sent_by_name'] ?? '-'); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100">
                        <button class="btn btn-sm btn-outline-secondary" onclick="viewEmail(<?php echo htmlspecialchars(json_encode($e)); ?>)">
                            <i class="bi bi-eye"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo render_pagination($pagination, BASE_URL . '/email/history.php'); ?>

<!-- View Email Modal -->
<div class="modal fade" id="viewEmailModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title">Email Details</h6>
                <button type="button" class="text-slate-400 hover:text-slate-600 font-bold" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-6">
                    <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold">Recipient:</label>
                    <p class="mb-0" id="viewRecipient">—</p>
                </div>
                <div class="mb-6">
                    <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold">Subject:</label>
                    <p class="mb-0" id="viewSubject">—</p>
                </div>
                <div class="mb-6">
                    <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold">Status:</label>
                    <p class="mb-0" id="viewStatus">—</p>
                </div>
                <div class="mb-6" id="viewErrorWrap" style="display:none;">
                    <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold text-red-600">Error:</label>
                    <p class="mb-0 text-red-600" id="viewError">—</p>
                </div>
                <div class="mb-6">
                    <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold">Resend ID:</label>
                    <p class="mb-0 font-monospace small" id="viewResendId">—</p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-slate-700 mb-1 font-semibold">Message:</label>
                    <pre class="bg-light p-3 rounded" id="viewBody" style="white-space: pre-wrap; font-family: inherit; font-size: 0.9rem;">—</pre>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
function viewEmail(email) {
    document.getElementById('viewRecipient').textContent = (email.recipient_name || '') + ' <' + email.recipient_email + '>';
    document.getElementById('viewSubject').textContent = email.subject;
    document.getElementById('viewBody').textContent = email.body;
    document.getElementById('viewResendId').textContent = email.resend_id || '—';

    const statusEl = document.getElementById('viewStatus');
    if (email.status === 'sent') {
        statusEl.innerHTML = '<span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">Sent</span>';
    } else {
        statusEl.innerHTML = '<span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">Failed</span>';
    }

    const errorWrap = document.getElementById('viewErrorWrap');
    const errorEl = document.getElementById('viewError');
    if (email.error_message) {
        errorWrap.style.display = 'block';
        errorEl.textContent = email.error_message;
    } else {
        errorWrap.style.display = 'none';
    }

    new bootstrap.Modal(document.getElementById('viewEmailModal')).show();
}
</script>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
