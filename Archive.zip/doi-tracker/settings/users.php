<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin']);

// ─── Handle Password Change ───
if (isset($_GET['action']) && $_GET['action'] === 'change_password') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
            set_flash('danger', 'Invalid form submission.');
            redirect(BASE_URL . '/settings/users.php?action=change_password');
        }

        $new_pass = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        if (strlen($new_pass) < 8) {
            set_flash('danger', 'Password must be at least 8 characters.');
            redirect(BASE_URL . '/settings/users.php?action=change_password');
        }
        if ($new_pass !== $confirm_pass) {
            set_flash('danger', 'Passwords do not match.');
            redirect(BASE_URL . '/settings/users.php?action=change_password');
        }

        $hash = password_hash($new_pass, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $_SESSION['user_id']]);
        unset($_SESSION['force_password_change']);

        set_flash('success', 'Password changed successfully.');
        redirect(BASE_URL . '/dashboard.php');
    }

    $page_title = 'Change Password';
    require_once __DIR__ . '/../helpers/layout_header.php';
    ?>
    <div class="flex flex-wrap -mx-3 justify-center">
        <div class="col-md-5">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header"><h6 class="mb-0 font-semibold">Change Your Password</h6></div>
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-6">
                            <label for="new_password" class="block text-sm font-medium text-slate-700 mb-1">New Password</label>
                            <input type="password" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="new_password" name="new_password" minlength="8" required>
                        </div>
                        <div class="mb-6">
                            <label for="confirm_password" class="block text-sm font-medium text-slate-700 mb-1">Confirm Password</label>
                            <input type="password" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="confirm_password" name="confirm_password" minlength="8" required>
                        </div>
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors w-100">Change Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php
    require_once __DIR__ . '/../helpers/layout_footer.php';
    exit;
}

// ─── Handle Create/Edit User ───
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect(BASE_URL . '/settings/users.php');
    }

    $edit_id = intval($_POST['edit_id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'campaign_manager';
    $allowed_roles = ['super_admin', 'campaign_manager', 'viewer'];
    if (!in_array($role, $allowed_roles)) {
        $role = 'campaign_manager';
    }
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    if (empty($username)) {
        set_flash('danger', 'Username is required.');
        redirect(BASE_URL . '/settings/users.php');
    }

    if ($edit_id) {
        // Update existing
        if ($password) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE users SET username=?, email=?, password=?, role=?, is_active=? WHERE id=?")
                ->execute([$username, $email, $hash, $role, $is_active, $edit_id]);
        } else {
            $pdo->prepare("UPDATE users SET username=?, email=?, role=?, is_active=? WHERE id=?")
                ->execute([$username, $email, $role, $is_active, $edit_id]);
        }
        set_flash('success', 'User updated.');
    } else {
        // Create new
        if (strlen($password) < 8) {
            set_flash('danger', 'Password must be at least 8 characters.');
            redirect(BASE_URL . '/settings/users.php');
        }

        // Check username uniqueness
        $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $check->execute([$username]);
        if ($check->fetch()) {
            set_flash('danger', 'Username already exists.');
            redirect(BASE_URL . '/settings/users.php');
        }

        // Check email uniqueness
        if (!empty($email)) {
            $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $check->execute([$email]);
            if ($check->fetch()) {
                set_flash('danger', 'Email already in use.');
                redirect(BASE_URL . '/settings/users.php');
            }
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $pdo->prepare("INSERT INTO users (username, email, password, role, is_active) VALUES (?, ?, ?, ?, ?)")
            ->execute([$username, $email, $hash, $role, $is_active]);
        set_flash('success', 'User created.');
    }

    regenerate_csrf_token();
    redirect(BASE_URL . '/settings/users.php');
}

// ─── Fetch Users ───
$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();

$page_title = 'User Management';
$page_actions = '<button class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors btn-sm" data-bs-toggle="modal" data-bs-target="#userModal" onclick="resetUserForm()"><i class="bi bi-plus-lg me-1"></i>Add User</button>';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<!-- Users Table -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="overflow-x-auto w-full">
        <table class="min-w-full text-left border-collapse mb-0">
            <thead>
                <tr>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Username</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Email</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Role</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Status</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Last Login</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Created</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><strong><?php echo sanitize($u['username']); ?></strong></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo sanitize($u['email'] ?? '-'); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><span class="badge bg-primary"><?php echo sanitize($u['role']); ?></span></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo $u['is_active'] ? '<span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">Active</span>' : '<span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800">Suspended</span>'; ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo $u['last_login'] ? time_ago($u['last_login']) : 'Never'; ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo time_ago($u['created_at']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100">
                        <button class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-1 px-3 rounded-lg text-sm transition-colors" onclick="editUser(<?php echo htmlspecialchars(json_encode($u)); ?>)">
                            <i class="bi bi-pencil"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- User Modal -->
<div class="modal fade" id="userModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="edit_id" id="edit_id" value="">
                <div class="modal-header">
                    <h6 class="modal-title" id="userModalTitle">Add User</h6>
                    <button type="button" class="text-slate-400 hover:text-slate-600 font-bold" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-6">
                        <label for="username" class="block text-sm font-medium text-slate-700 mb-1">Username <span class="text-red-600">*</span></label>
                        <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="username" name="username" required>
                    </div>
                    <div class="mb-6">
                        <label for="email" class="block text-sm font-medium text-slate-700 mb-1">Email</label>
                        <input type="email" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="email" name="email">
                    </div>
                    <div class="mb-6">
                        <label for="password" class="block text-sm font-medium text-slate-700 mb-1" id="password_label">Password <span class="text-red-600">*</span></label>
                        <input type="password" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="password" name="password" minlength="8">
                        <small class="text-slate-500" id="password_help">Min 8 characters</small>
                    </div>
                    <div class="mb-6">
                        <label for="role" class="block text-sm font-medium text-slate-700 mb-1">Role</label>
                        <select class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white" id="role" name="role">
                            <option value="campaign_manager">Campaign Manager</option>
                            <option value="viewer">Viewer (Read-only)</option>
                            <option value="super_admin">Super Admin</option>
                        </select>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="is_active" name="is_active" checked>
                        <label class="form-check-label" for="is_active">Active</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium py-2 px-4 rounded-lg transition-colors" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetUserForm() {
    document.getElementById('edit_id').value = '';
    document.getElementById('username').value = '';
    document.getElementById('email').value = '';
    document.getElementById('password').value = '';
    document.getElementById('password').required = true;
    document.getElementById('role').value = 'campaign_manager';
    document.getElementById('is_active').checked = true;
    document.getElementById('userModalTitle').textContent = 'Add User';
    document.getElementById('password_label').innerHTML = 'Password <span class="text-red-600">*</span>';
    document.getElementById('password_help').textContent = 'Min 8 characters';
}

function editUser(user) {
    document.getElementById('edit_id').value = user.id;
    document.getElementById('username').value = user.username;
    document.getElementById('email').value = user.email || '';
    document.getElementById('password').value = '';
    document.getElementById('password').required = false;
    document.getElementById('role').value = user.role;
    document.getElementById('is_active').checked = user.is_active == 1;
    document.getElementById('userModalTitle').textContent = 'Edit User';
    document.getElementById('password_label').innerHTML = 'New Password <small class="text-slate-500">(leave blank to keep current)</small>';
    document.getElementById('password_help').textContent = '';
    new bootstrap.Modal(document.getElementById('userModal')).show();
}

// Clean up rate limits periodically (1 in 50 chance on login page load)
if (Math.random() < 0.02) {
    fetch('<?php echo BASE_URL; ?>/auth.php?action=cleanup_ratelimits', { method: 'GET', mode: 'no-cors' });
}
</script>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
