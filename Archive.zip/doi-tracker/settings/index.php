<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin']);

// ─── Handle POST ───
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect(BASE_URL . '/settings/index.php');
    }

    $keys = ['site_name', 'default_currency', 'session_timeout_hours', 'smtp_enabled', 'smtp_host', 'smtp_port', 'smtp_user', 'resend_api_key', 'email_from_address', 'email_from_name'];
    foreach ($keys as $key) {
        if (isset($_POST[$key])) {
            set_setting($pdo, $key, trim($_POST[$key]));
        }
    }

    // Encrypt SMTP password before storing
    if (isset($_POST['smtp_pass']) && !empty($_POST['smtp_pass'])) {
        set_setting($pdo, 'smtp_pass', encrypt_value(trim($_POST['smtp_pass'])));
    }

    regenerate_csrf_token();
    set_flash('success', 'Settings saved.');
    redirect(BASE_URL . '/settings/index.php');
}

// ─── Load Current Settings ───
$settings = [];
$stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
while ($row = $stmt->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}

$page_title = 'System Settings';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<div class="flex flex-wrap -mx-3 justify-center">
    <div class="col-lg-8 max-w-3xl mx-auto">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden-header">
                <h6 class="mb-0 font-semibold">General Settings</h6>
            </div>
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-wrap -mx-3 g-3">
                        <div class="w-full md:w-1/2 px-3">
                            <label for="site_name" class="block text-sm font-medium text-slate-700 mb-1">Site Name</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="site_name" name="site_name"
                                   value="<?php echo sanitize($settings['site_name'] ?? 'Ternfluenzy'); ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="default_currency" class="block text-sm font-medium text-slate-700 mb-1">Default Currency</label>
                            <select class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white" id="default_currency" name="default_currency">
                                <?php foreach (['USD','EUR','GBP','INR','AED','SAR','CAD','AUD'] as $cur): ?>
                                <option value="<?php echo $cur; ?>" <?php echo ($settings['default_currency'] ?? 'USD') === $cur ? 'selected' : ''; ?>><?php echo $cur; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="session_timeout_hours" class="block text-sm font-medium text-slate-700 mb-1">Session Timeout (hrs)</label>
                            <input type="number" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="session_timeout_hours" name="session_timeout_hours"
                                   value="<?php echo $settings['session_timeout_hours'] ?? 8; ?>" min="1" max="72">
                        </div>

                        <div class="w-full px-3"><hr><h6 class="font-semibold">Email (Resend) Configuration</h6></div>

                        <div class="w-full md:w-1/2 px-3">
                            <label for="resend_api_key" class="block text-sm font-medium text-slate-700 mb-1">Resend API Key</label>
                            <input type="password" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="resend_api_key" name="resend_api_key"
                                   value="<?php echo sanitize($settings['resend_api_key'] ?? ''); ?>"
                                   placeholder="re_...">
                            <small class="text-slate-500">Get your API key from <a href="https://resend.com" target="_blank" rel="noopener">resend.com</a></small>
                        </div>
                        <div class="col-md-3">
                            <label for="email_from_address" class="block text-sm font-medium text-slate-700 mb-1">From Address</label>
                            <input type="email" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="email_from_address" name="email_from_address"
                                   value="<?php echo sanitize($settings['email_from_address'] ?? 'noreply@yourdomain.com'); ?>"
                                   placeholder="noreply@yourdomain.com">
                        </div>
                        <div class="col-md-3">
                            <label for="email_from_name" class="block text-sm font-medium text-slate-700 mb-1">From Name</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="email_from_name" name="email_from_name"
                                   value="<?php echo sanitize($settings['email_from_name'] ?? 'Ternfluenzy'); ?>"
                                   placeholder="Ternfluenzy">
                        </div>

                        <div class="w-full px-3"><hr><h6 class="font-semibold">SMTP Configuration</h6></div>

                        <div class="col-md-3">
                            <label for="smtp_enabled" class="block text-sm font-medium text-slate-700 mb-1">SMTP Enabled</label>
                            <select class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white" id="smtp_enabled" name="smtp_enabled">
                                <option value="0" <?php echo ($settings['smtp_enabled'] ?? '0') === '0' ? 'selected' : ''; ?>>No</option>
                                <option value="1" <?php echo ($settings['smtp_enabled'] ?? '0') === '1' ? 'selected' : ''; ?>>Yes</option>
                            </select>
                        </div>
                        <div class="col-md-5">
                            <label for="smtp_host" class="block text-sm font-medium text-slate-700 mb-1">SMTP Host</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="smtp_host" name="smtp_host"
                                   value="<?php echo sanitize($settings['smtp_host'] ?? ''); ?>">
                        </div>
                        <div class="w-full md:w-1/3 px-3">
                            <label for="smtp_port" class="block text-sm font-medium text-slate-700 mb-1">SMTP Port</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="smtp_port" name="smtp_port"
                                   value="<?php echo sanitize($settings['smtp_port'] ?? '587'); ?>">
                        </div>
                        <div class="w-full md:w-1/2 px-3">
                            <label for="smtp_user" class="block text-sm font-medium text-slate-700 mb-1">SMTP Username</label>
                            <input type="text" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="smtp_user" name="smtp_user"
                                   value="<?php echo sanitize($settings['smtp_user'] ?? ''); ?>">
                        </div>
                        <div class="w-full md:w-1/2 px-3">
                            <label for="smtp_pass" class="block text-sm font-medium text-slate-700 mb-1">SMTP Password</label>
                            <input type="password" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border" id="smtp_pass" name="smtp_pass"
                                   value="" placeholder="<?php echo !empty($settings['smtp_pass'] ?? '') ? '(encrypted — leave blank to keep current)' : ''; ?>">
                            <?php if (!empty($settings['smtp_pass'] ?? '')): ?>
                            <small class="text-slate-500">Password is encrypted. Leave blank to keep current.</small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="mt-6">
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg shadow-sm transition-colors"><i class="bi bi-check-lg me-1"></i>Save Settings</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
