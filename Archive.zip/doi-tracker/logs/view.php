<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

// ─── Filters ───
$log_type = $_GET['type'] ?? '';
$status_filter = $_GET['status'] ?? '';
$date_from = sanitize($_GET['from'] ?? '');
$date_to = sanitize($_GET['to'] ?? '');
if ($date_from && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from)) $date_from = '';
if ($date_to && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to)) $date_to = '';
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 100;

$where = [];
$params = [];

if ($log_type) {
    $where[] = "l.log_type = ?";
    $params[] = $log_type;
}
if ($status_filter) {
    $where[] = "l.status = ?";
    $params[] = $status_filter;
}
if ($date_from) {
    $where[] = "l.created_at >= ?";
    $params[] = $date_from;
}
if ($date_to) {
    $where[] = "l.created_at <= DATE_ADD(?, INTERVAL 1 DAY)";
    $params[] = $date_to;
}

$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$count_stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM logs l $where_sql");
$count_stmt->execute($params);
$total = $count_stmt->fetch()['cnt'];

$pagination = paginate($total, $per_page, $page);

$stmt = $pdo->prepare("
    SELECT l.*, p.project_code, v.vendor_name
    FROM logs l
    LEFT JOIN projects p ON l.project_id = p.id
    LEFT JOIN vendors v ON l.vendor_id = v.id
    $where_sql
    ORDER BY l.created_at DESC
    LIMIT {$pagination['per_page']} OFFSET {$pagination['offset']}
");
$stmt->execute($params);
$logs = $stmt->fetchAll();

$log_types = ['click', 'postback', 'error', 'status_change', 'manual', 'vendor_postback', 'login', 'vendor_change'];
$statuses = ['success', 'failed', 'duplicate', 'rejected'];

$page_title = 'System Logs';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<!-- Filters -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mb-6">
    <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6 py-2">
        <form method="GET" class="flex flex-wrap -mx-3 g-2 align-items-end">
            <div class="col-md-2">
                <select name="type" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white-sm">
                    <option value="">All Types</option>
                    <?php foreach ($log_types as $lt): ?>
                    <option value="<?php echo $lt; ?>" <?php echo $log_type === $lt ? 'selected' : ''; ?>><?php echo $lt; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="status" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border bg-white-sm">
                    <option value="">All Status</option>
                    <?php foreach ($statuses as $s): ?>
                    <option value="<?php echo $s; ?>" <?php echo $status_filter === $s ? 'selected' : ''; ?>><?php echo ucfirst($s); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <input type="date" name="from" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm" value="<?php echo $date_from; ?>" placeholder="From">
            </div>
            <div class="col-md-2">
                <input type="date" name="to" class="w-full rounded-lg border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm px-3 py-2 border-sm" value="<?php echo $date_to; ?>" placeholder="To">
            </div>
            <div class="col-md-2">
                <button type="submit" class="border border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-medium py-1 px-3 rounded-lg text-sm transition-colors w-100">Filter</button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo BASE_URL; ?>/logs/view.php" class="btn btn-sm btn-outline-secondary w-100">Clear</a>
            </div>
        </form>
    </div>
</div>

<!-- Logs Table -->
<div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="overflow-x-auto w-full">
        <table class="min-w-full text-left border-collapse min-w-full text-left border-collapse-sm mb-0">
            <thead>
                <tr>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Time</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Type</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Status</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Project</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Vendor</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Click ID</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">Message</th>
                    <th class="px-4 py-3 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">IP</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                <tr><td colspan="8" class="text-center text-slate-500 py-4">No logs found.</td></tr>
                <?php else: ?>
                <?php foreach ($logs as $log): ?>
                <tr>
                    <td class="text-nowrap small"><?php echo time_ago($log['created_at']); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><span class="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800"><?php echo sanitize($log['log_type']); ?></span></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo status_badge($log['status'] ?? '-'); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo $log['project_code'] ? '<code>' . sanitize($log['project_code']) . '</code>' : '-'; ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo sanitize($log['vendor_name'] ?? '-'); ?></td>
                    <td class="px-4 py-4 whitespace-nowrap text-sm text-slate-700 border-b border-slate-100"><?php echo $log['click_id'] ? '<code class="small">' . substr($log['click_id'], 0, 12) . '...</code>' : '-'; ?></td>
                    <td class="small"><?php echo sanitize($log['message'] ?? ''); ?></td>
                    <td class="small text-slate-500"><?php echo sanitize($log['ip_address'] ?? ''); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
echo render_pagination($pagination, BASE_URL . '/logs/view.php');
require_once __DIR__ . '/../helpers/layout_footer.php';
?>
