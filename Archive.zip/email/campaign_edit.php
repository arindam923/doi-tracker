<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

$id = intval($_GET['id'] ?? 0);
if (!$id) redirect(BASE_URL . '/email/campaigns.php');

$stmt = $pdo->prepare("SELECT ec.*, p.project_code, p.project_name, p.country_target FROM email_campaigns ec JOIN projects p ON ec.project_id = p.id WHERE ec.id = ?");
$stmt->execute([$id]);
$campaign = $stmt->fetch();
if (!$campaign) {
    set_flash('danger', 'Campaign not found.');
    redirect(BASE_URL . '/email/campaigns.php');
}

$vendors = $pdo->prepare("SELECT * FROM vendors WHERE project_id = ? ORDER BY vendor_name");
$vendors->execute([$campaign['project_id']]);
$vendors = $vendors->fetchAll();

$templates = $pdo->query("SELECT id, name, subject FROM email_templates ORDER BY is_default DESC, name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect(BASE_URL . '/email/campaign_edit.php?id=' . $id);
    }

    $vendor_id = intval($_POST['vendor_id'] ?? 0);
    $template_id = intval($_POST['template_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $html_body = trim($_POST['html_body'] ?? '');
    $from_name = trim($_POST['from_name'] ?? '');
    $from_email = trim($_POST['from_email'] ?? '');
    $daily_limit = intval($_POST['daily_limit'] ?? 1000);
    $total_limit = intval($_POST['total_limit'] ?? 0);
    $is_multi_step = !empty($_POST['is_multi_step']) ? 1 : 0;

    $errors = [];
    if (!$vendor_id) $errors[] = 'Please select a vendor.';
    if ($name === '') $errors[] = 'Campaign name is required.';
    if ($subject === '') $errors[] = 'Subject is required.';
    if ($html_body === '') $errors[] = 'HTML body is required.';
    if ($daily_limit < 1) $errors[] = 'Daily limit must be at least 1.';

    if (!empty($errors)) {
        set_flash('danger', implode(' | ', $errors));
        redirect(BASE_URL . '/email/campaign_edit.php?id=' . $id);
    }

    try {
        $stmt = $pdo->prepare("UPDATE email_campaigns SET vendor_id=?, template_id=?, name=?, subject=?, html_body=?, from_name=?, from_email=?, daily_limit=?, total_limit=?, is_multi_step=?, updated_at=NOW() WHERE id=?");
        $stmt->execute([$vendor_id, $template_id ?: null, $name, $subject, $html_body, $from_name ?: null, $from_email ?: null, $daily_limit, $total_limit, $is_multi_step, $id]);

        audit_log($pdo, 'update', 'email_campaign', $id, null, ['name' => $name]);
        set_flash('success', 'Campaign updated.');
        redirect(BASE_URL . '/email/campaign_detail.php?id=' . $id);
    } catch (Throwable $e) {
        error_log('Campaign update failed: ' . $e->getMessage());
        set_flash('danger', 'Failed to update campaign.');
        redirect(BASE_URL . '/email/campaign_edit.php?id=' . $id);
    }
}

$page_title = 'Edit Campaign';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<div class="row justify-content-center">
    <div class="col-12 col-xl-10">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-bottom py-3">
                <div class="d-flex flex-column">
                    <h5 class="mb-0 fw-semibold">Edit Campaign</h5>
                    <small class="text-muted">Project: <code><?php echo sanitize($campaign['project_code']); ?></code> — <?php echo sanitize($campaign['project_name']); ?></small>
                </div>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <label for="vendor_id" class="form-label small fw-semibold text-secondary">Email Vendor <span class="text-danger">*</span></label>
                            <select id="vendor_id" name="vendor_id" class="form-select" required>
                                <option value="">Select Vendor</option>
                                <?php foreach ($vendors as $v): ?>
                                    <option value="<?php echo (int)$v['id']; ?>" <?php echo $campaign['vendor_id'] == $v['id'] ? 'selected' : ''; ?>><?php echo sanitize($v['vendor_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="template_id" class="form-label small fw-semibold text-secondary">Template</label>
                            <select id="template_id" name="template_id" class="form-select" onchange="applyTemplate()">
                                <option value="">Custom / Blank</option>
                                <?php foreach ($templates as $t): ?>
                                    <option value="<?php echo (int)$t['id']; ?>" data-subject="<?php echo sanitize($t['subject']); ?>" data-html="<?php echo sanitize($t['html_body']); ?>" <?php echo $campaign['template_id'] == $t['id'] ? 'selected' : ''; ?>><?php echo sanitize($t['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <label for="name" class="form-label small fw-semibold text-secondary">Campaign Name <span class="text-danger">*</span></label>
                            <input type="text" id="name" name="name" class="form-control" value="<?php echo sanitize($campaign['name']); ?>" required>
                        </div>
                        <div class="col-12">
                            <label for="subject" class="form-label small fw-semibold text-secondary">Subject <span class="text-danger">*</span></label>
                            <input type="text" id="subject" name="subject" class="form-control" value="<?php echo sanitize($campaign['subject']); ?>" required>
                        </div>
                        <div class="col-12">
                            <label for="html_body" class="form-label small fw-semibold text-secondary">HTML Body <span class="text-danger">*</span></label>
                            <textarea id="html_body" name="html_body" class="form-control" rows="14" required placeholder="<html>...</html>"><?php echo sanitize($campaign['html_body']); ?></textarea>
                        </div>
                        <div class="col-6 col-md-3">
                            <label for="daily_limit" class="form-label small fw-semibold text-secondary">Daily Limit <span class="text-danger">*</span></label>
                            <input type="number" id="daily_limit" name="daily_limit" class="form-control" value="<?php echo (int)$campaign['daily_limit']; ?>" min="1" required>
                        </div>
                        <div class="col-6 col-md-3">
                            <label for="total_limit" class="form-label small fw-semibold text-secondary">Total Limit</label>
                            <input type="number" id="total_limit" name="total_limit" class="form-control" value="<?php echo (int)$campaign['total_limit']; ?>" min="0">
                            <p class="form-text mb-0 small">0 = unlimited</p>
                        </div>
                        <div class="col-6 col-md-3">
                            <label for="from_name" class="form-label small fw-semibold text-secondary">From Name</label>
                            <input type="text" id="from_name" name="from_name" class="form-control" value="<?php echo sanitize($campaign['from_name'] ?? ''); ?>">
                        </div>
                        <div class="col-6 col-md-3">
                            <label for="from_email" class="form-label small fw-semibold text-secondary">From Email</label>
                            <input type="email" id="from_email" name="from_email" class="form-control" value="<?php echo sanitize($campaign['from_email'] ?? ''); ?>">
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_multi_step" name="is_multi_step" value="1" <?php echo $campaign['is_multi_step'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="is_multi_step">Allow multiple emails to same recipient for this campaign</label>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end gap-2 pt-3 mt-3 border-top">
                        <a href="<?php echo BASE_URL; ?>/email/campaign_detail.php?id=<?php echo (int)$id; ?>" class="btn btn-secondary">Cancel</a>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i>Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function applyTemplate() {
    const sel = document.getElementById('template_id');
    const subject = document.getElementById('subject');
    const html = document.getElementById('html_body');
    const opt = sel.options[sel.selectedIndex];
    if (opt && opt.dataset.subject) {
        subject.value = opt.dataset.subject;
        html.value = opt.dataset.html;
    }
}
</script>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
