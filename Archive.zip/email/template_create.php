<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

$page_title = 'New Email Template';
require_once __DIR__ . '/../helpers/layout_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect(BASE_URL . '/email/template_create.php');
    }

    $name = trim($_POST['name'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $html_body = trim($_POST['html_body'] ?? '');
    $is_default = !empty($_POST['is_default']) ? 1 : 0;

    $errors = [];
    if ($name === '') $errors[] = 'Template name is required.';
    if ($subject === '') $errors[] = 'Subject is required.';
    if ($html_body === '') $errors[] = 'HTML body is required.';

    if (!empty($errors)) {
        set_flash('danger', implode(' | ', $errors));
        $_SESSION['form_data'] = $_POST;
        redirect(BASE_URL . '/email/template_create.php');
    }

    try {
        if ($is_default) {
            $pdo->prepare("UPDATE email_templates SET is_default = 0")->execute();
        }

        $stmt = $pdo->prepare("INSERT INTO email_templates (name, subject, html_body, is_default, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())");
        $stmt->execute([$name, $subject, $html_body, $is_default, $_SESSION['user_id'] ?? null]);

        $new_id = (int)$pdo->lastInsertId();
        audit_log($pdo, 'create', 'email_template', $new_id, null, ['name' => $name]);
        set_flash('success', 'Template created.');
        redirect(BASE_URL . '/email/templates.php');
    } catch (Throwable $e) {
        error_log('Template create failed: ' . $e->getMessage());
        set_flash('danger', 'Failed to create template.');
        redirect(BASE_URL . '/email/template_create.php');
    }
}

$form_data = $_SESSION['form_data'] ?? [];
unset($_SESSION['form_data']);
require_once __DIR__ . '/../helpers/layout_footer.php';
?>
