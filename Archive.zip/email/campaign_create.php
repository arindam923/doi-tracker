<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

$project_id = intval($_GET['project_id'] ?? 0);
if (!$project_id) redirect(BASE_URL . '/projects/list.php');

$stmt = $pdo->prepare("SELECT p.*, c.default_currency FROM projects p LEFT JOIN clients c ON p.client_id = c.id WHERE p.id = ?");
$stmt->execute([$project_id]);
$project = $stmt->fetch();
if (!$project) {
    set_flash('danger', 'Project not found.');
    redirect(BASE_URL . '/projects/list.php');
}

$vendors = $pdo->prepare("SELECT * FROM vendors WHERE project_id = ? ORDER BY vendor_name");
$vendors->execute([$project_id]);
$vendors = $vendors->fetchAll();

$templates = $pdo->query("SELECT id, name, subject FROM email_templates ORDER BY is_default DESC, name ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect(BASE_URL . '/email/campaign_create.php?project_id=' . $project_id);
    }

    $vendor_id = intval($_POST['vendor_id'] ?? 0);
    $template_id = intval($_POST['template_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $html_body = trim($_POST['html_body'] ?? '');
    $from_name = trim($_POST['from_name'] ?? '');
    $from_email = trim($_POST['from_email'] ?? '');
    $daily_limit = intval($_POST['daily_limit'] ?? 1000);
    $total_limit = intval($_POST['total_limit'] ?? 0);
    $is_multi_step = !empty($_POST['is_multi_step']) ? 1 : 0;

    $errors = [];
    if (!$vendor_id) $errors[] = 'Please select a vendor.';
    if ($name === '') $errors[] = 'Campaign name is required.';
    if ($subject === '') $errors[] = 'Subject is required.';
    if ($html_body === '') $errors[] = 'HTML body is required.';
    if ($daily_limit < 1) $errors[] = 'Daily limit must be at least 1.';

    if (!empty($errors)) {
        set_flash('danger', implode(' | ', $errors));
        $_SESSION['form_data'] = $_POST;
        redirect(BASE_URL . '/email/campaign_create.php?project_id=' . $project_id);
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO email_campaigns (project_id, vendor_id, template_id, name, subject, html_body, from_name, from_email, daily_limit, total_limit, is_multi_step, status, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, NOW(), NOW())");
        $stmt->execute([$project_id, $vendor_id, $template_id ?: null, $name, $subject, $html_body, $from_name ?: null, $from_email ?: null, $daily_limit, $total_limit, $is_multi_step, $_SESSION['user_id'] ?? null]);

        $new_id = (int)$pdo->lastInsertId();
        audit_log($pdo, 'create', 'email_campaign', $new_id, null, ['project_id' => $project_id, 'vendor_id' => $vendor_id, 'name' => $name]);
        set_flash('success', 'Campaign created.');
        redirect(BASE_URL . '/email/campaigns.php?project_id=' . $project_id);
    } catch (Throwable $e) {
        error_log('Campaign create failed: ' . $e->getMessage());
        set_flash('danger', 'Failed to create campaign.');
        redirect(BASE_URL . '/email/campaign_create.php?project_id=' . $project_id);
    }
}

$form_data = $_SESSION['form_data'] ?? [];
unset($_SESSION['form_data']);
$page_title = 'New Email Campaign';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<div class="row justify-content-center">
    <div class="col-12 col-xl-10">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-bottom py-3">
                <div class="d-flex flex-column">
                    <h5 class="mb-0 fw-semibold">New Email Campaign</h5>
                    <small class="text-muted">Project: <code><?php echo sanitize($project['project_code']); ?></code> — <?php echo sanitize($project['project_name']); ?></small>
                </div>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <label for="vendor_id" class="form-label small fw-semibold text-secondary">Email Vendor <span class="text-danger">*</span></label>
                            <select id="vendor_id" name="vendor_id" class="form-select" required>
                                <option value="">Select Vendor</option>
                                <?php foreach ($vendors as $v): ?>
                                    <option value="<?php echo (int)$v['id']; ?>" <?php echo ($form_data['vendor_id'] ?? '') == $v['id'] ? 'selected' : ''; ?>><?php echo sanitize($v['vendor_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="template_id" class="form-label small fw-semibold text-secondary">Template</label>
                            <select id="template_id" name="template_id" class="form-select" onchange="applyTemplate()">
                                <option value="">Custom / Blank</option>
                                <?php foreach ($templates as $t): ?>
                                    <option value="<?php echo (int)$t['id']; ?>" data-subject="<?php echo sanitize($t['subject']); ?>" data-html="<?php echo sanitize($t['html_body']); ?>"><?php echo sanitize($t['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <label for="name" class="form-label small fw-semibold text-secondary">Campaign Name <span class="text-danger">*</span></label>
                            <input type="text" id="name" name="name" class="form-control" value="<?php echo sanitize($form_data['name'] ?? ''); ?>" required>
                        </div>
                        <div class="col-12">
                            <label for="subject" class="form-label small fw-semibold text-secondary">Subject <span class="text-danger">*</span></label>
                            <input type="text" id="subject" name="subject" class="form-control" value="<?php echo sanitize($form_data['subject'] ?? ''); ?>" required>
                        </div>
                        <div class="col-12">
                            <label for="html_body" class="form-label small fw-semibold text-secondary">HTML Body <span class="text-danger">*</span></label>
                            <textarea id="html_body" name="html_body" class="form-control" rows="14" required placeholder="<html>...</html>"><?php echo sanitize($form_data['html_body'] ?? ''); ?></textarea>
                            <p class="form-text">Supports standard HTML. Merge field example: <code>{{name}}</code>, <code>{{email}}</code>, <code>{{country}}</code>.</p>
                        </div>
                        <div class="col-6 col-md-3">
                            <label for="daily_limit" class="form-label small fw-semibold text-secondary">Daily Limit <span class="text-danger">*</span></label>
                            <input type="number" id="daily_limit" name="daily_limit" class="form-control" value="<?php echo sanitize($form_data['daily_limit'] ?? '1000'); ?>" min="1" required>
                        </div>
                        <div class="col-6 col-md-3">
                            <label for="total_limit" class="form-label small fw-semibold text-secondary">Total Limit</label>
                            <input type="number" id="total_limit" name="total_limit" class="form-control" value="<?php echo sanitize($form_data['total_limit'] ?? '0'); ?>" min="0">
                            <p class="form-text mb-0 small">0 = unlimited</p>
                        </div>
                        <div class="col-6 col-md-3">
                            <label for="from_name" class="form-label small fw-semibold text-secondary">From Name</label>
                            <input type="text" id="from_name" name="from_name" class="form-control" value="<?php echo sanitize($form_data['from_name'] ?? ''); ?>">
                        </div>
                        <div class="col-6 col-md-3">
                            <label for="from_email" class="form-label small fw-semibold text-secondary">From Email</label>
                            <input type="email" id="from_email" name="from_email" class="form-control" value="<?php echo sanitize($form_data['from_email'] ?? ''); ?>">
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_multi_step" name="is_multi_step" value="1" <?php echo !empty($form_data['is_multi_step']) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="is_multi_step">Allow multiple emails to same recipient for this campaign</label>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end gap-2 pt-3 mt-3 border-top">
                        <a href="<?php echo BASE_URL; ?>/email/campaigns.php?project_id=<?php echo (int)$project_id; ?>" class="btn btn-secondary">Cancel</a>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i>Create Campaign</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function applyTemplate() {
    const sel = document.getElementById('template_id');
    const subject = document.getElementById('subject');
    const html = document.getElementById('html_body');
    const opt = sel.options[sel.selectedIndex];
    if (opt && opt.dataset.subject) {
        subject.value = opt.dataset.subject;
        html.value = opt.dataset.html;
    }
}
</script>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
