<?php
require_once __DIR__ . '/../config.php';
require_role(['super_admin', 'campaign_manager']);

$id = intval($_GET['id'] ?? 0);
if (!$id) redirect(BASE_URL . '/email/templates.php');

$stmt = $pdo->prepare("SELECT * FROM email_templates WHERE id = ?");
$stmt->execute([$id]);
$tpl = $stmt->fetch();
if (!$tpl) {
    set_flash('danger', 'Template not found.');
    redirect(BASE_URL . '/email/templates.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid form submission.');
        redirect(BASE_URL . '/email/template_edit.php?id=' . $id);
    }

    $name = trim($_POST['name'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $html_body = trim($_POST['html_body'] ?? '');
    $is_default = !empty($_POST['is_default']) ? 1 : 0;

    $errors = [];
    if ($name === '') $errors[] = 'Template name is required.';
    if ($subject === '') $errors[] = 'Subject is required.';
    if ($html_body === '') $errors[] = 'HTML body is required.';

    if (!empty($errors)) {
        set_flash('danger', implode(' | ', $errors));
        redirect(BASE_URL . '/email/template_edit.php?id=' . $id);
    }

    try {
        if ($is_default) {
            $pdo->prepare("UPDATE email_templates SET is_default = 0")->execute();
        }

        $stmt = $pdo->prepare("UPDATE email_templates SET name=?, subject=?, html_body=?, is_default=?, updated_at=NOW() WHERE id=?");
        $stmt->execute([$name, $subject, $html_body, $is_default, $id]);

        audit_log($pdo, 'update', 'email_template', $id, null, ['name' => $name]);
        set_flash('success', 'Template updated.');
        redirect(BASE_URL . '/email/templates.php');
    } catch (Throwable $e) {
        error_log('Template update failed: ' . $e->getMessage());
        set_flash('danger', 'Failed to update template.');
        redirect(BASE_URL . '/email/template_edit.php?id=' . $id);
    }
}

$page_title = 'Edit Template';
require_once __DIR__ . '/../helpers/layout_header.php';
?>

<div class="row justify-content-center">
    <div class="col-12 col-xl-10">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-bottom py-3">
                <h5 class="mb-0 fw-semibold">Edit: <?php echo sanitize($tpl['name']); ?></h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <label for="name" class="form-label small fw-semibold text-secondary">Name <span class="text-danger">*</span></label>
                            <input type="text" id="name" name="name" class="form-control" value="<?php echo sanitize($tpl['name']); ?>" required>
                        </div>
                        <div class="col-12 col-md-6">
                            <label for="subject" class="form-label small fw-semibold text-secondary">Subject <span class="text-danger">*</span></label>
                            <input type="text" id="subject" name="subject" class="form-control" value="<?php echo sanitize($tpl['subject']); ?>" required>
                        </div>
                        <div class="col-12">
                            <label for="html_body" class="form-label small fw-semibold text-secondary">HTML Body <span class="text-danger">*</span></label>
                            <textarea id="html_body" name="html_body" class="form-control" rows="14" required placeholder="<html>...</html>"><?php echo sanitize($tpl['html_body']); ?></textarea>
                            <p class="form-text">Full HTML email. You can use standard merge fields like <code>{{name}}</code>.</p>
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_default" name="is_default" value="1" <?php echo $tpl['is_default'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="is_default">Make this the default template</label>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end gap-2 pt-3 mt-3 border-top">
                        <a href="<?php echo BASE_URL; ?>/email/templates.php" class="btn btn-secondary">Cancel</a>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i>Save Template</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../helpers/layout_footer.php'; ?>
