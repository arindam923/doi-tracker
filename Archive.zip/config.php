<?php
// ─── Secrets loader (Phase 9 hardening) ─────────────────────────
// Prefer an out-of-document-root env.php (sibling of this project dir).
// Falls back to inline defaults so existing installs keep working.
$__env = __DIR__ . '/../env.php';
if (is_file($__env)) { require_once $__env; }

// ─── Database Configuration ───
if (!defined('DB_HOST')) define('DB_HOST', 'sql101.infinityfree.com');
if (!defined('DB_NAME')) define('DB_NAME', 'if0_42562417_turnflow');
if (!defined('DB_USER')) define('DB_USER', 'if0_42533255');
if (!defined('DB_PASS')) define('DB_PASS', 'vamaC9JgzFRljk');

// ─── Site Configuration ───
if (!defined('BASE_URL')) define('BASE_URL', 'arindam2.wuaze.com');
define('SITE_NAME', 'Track Flow');
define('SESSION_TIMEOUT_HOURS', 8);
if (!defined('ENCRYPTION_KEY')) define('ENCRYPTION_KEY', '1bee453ee7dbde0a971b17254cd94d2eeb212f7347ecaf59b9cef5b5ac92b324');
if (ENCRYPTION_KEY === 'change_this_to_a_random_32_char_string_in_production' && $_SERVER['SERVER_NAME'] !== 'localhost') {
    error_log('WARNING: Default ENCRYPTION_KEY in use. Generate a unique key for production.');
}

// ─── Error Reporting ───
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ─── Database Connection ───
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Track Flow DB connection failed: ' . $e->getMessage());
    die('System error. Please try again later.');
}

// ─── Session Configuration ───
ini_set('session.gc_maxlifetime', SESSION_TIMEOUT_HOURS * 3600);
ini_set('session.gc_probability', 1);
ini_set('session.gc_divisor', 100);
$__secure_cookie = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
session_name('ternfluenzy_session');
session_set_cookie_params([
    'lifetime' => SESSION_TIMEOUT_HOURS * 3600,
    'path' => '/',
    'httponly' => true,
    'secure' => $__secure_cookie,
    'samesite' => 'Lax',
]);
session_start();

// Regenerate session ID periodically to prevent fixation
if (!isset($_SESSION['_last_regen']) || time() - $_SESSION['_last_regen'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['_last_regen'] = time();
}

// ─── Load Helpers ───
require_once __DIR__ . '/helpers/functions.php';
require_once __DIR__ . '/helpers/csrf.php';
require_once __DIR__ . '/helpers/auth_middleware.php';
require_once __DIR__ . '/helpers/constants.php';
